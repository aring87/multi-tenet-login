## Change and reason

## Affected targets

List every target selecting the changed rule. Indicate which targets will be rolled out first.

## Rule identity and behavior

- Existing/new rule IDs:
- Query or schedule changes:
- Enabled/disabled changes:
- Client-specific overrides:

## Checks

- [ ] Offline CI passes.
- [ ] Target tenant/subscription/workspace and rule IDs verified.
- [ ] No credentials or raw client event samples included.
- [ ] MITRE migration exceptions, if any, are documented.
- [ ] No unintended target or rule inclusion.
- [ ] Workflow/role changes received security review.
- [ ] Preview and production rollout owner identified.
- [ ] Rollback or explicit deletion plan documented.

## Change ticket and rollout notes
