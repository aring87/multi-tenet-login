<img src="docs/images/isi-logo.png" alt="ISI" width="200">

# ISI Defense - Sentinel Detection-as-Code

Manage Microsoft Sentinel analytics rules from one private GitHub repository, with a shared YAML rule library and a separate deployment target per client workspace.

**Status: 41 client workspaces configured.** Every target is enabled and authenticates through the managing tenant. End-to-end validation, query checks, preview, production approval, and deployment were first exercised on `isi-enterprise-workspace-commercial`, `client-03-workspace-commercial`, `client-07-workspace-commercial` and `client-04-workspace-commercial`, including a multi-workspace fan-out run. The other targets were onboarded through the companion onboarding app and currently select only the disabled pipeline connection-test rule.

_Last updated: October 1, 2026. Status reflects the repository contents and work confirmed during implementation; it is not a live status feed._

## Contents

1. [Clients](#clients)
   - [Client notes](#client-notes)
2. [Access model](#access-model)
   - [Why built-in roles](#why-built-in-roles)
   - [Credential scoping](#credential-scoping)
   - [Lighthouse delegation](#lighthouse-delegation)
3. [How the pipeline works](#how-the-pipeline-works)
4. [Repository structure](#repository-structure)
   - [Rule library](#rule-library)
5. [Workflow reference](#workflow-reference)
6. [Quick start: add a rule](#quick-start-add-a-rule)
   - [Example target selection](#example-target-selection)
   - [Reading a preview's what-if](#reading-a-previews-what-if)
7. [Understand the enabled settings](#understand-the-enabled-settings)
8. [Onboarding a new client](#onboarding-a-new-client)
9. [Rule authoring conventions](#rule-authoring-conventions)
10. [What successful checks mean](#what-successful-checks-mean)
11. [Next milestones](#next-milestones)
12. [Operating boundaries](#operating-boundaries)
13. [Change records](#change-records)

---

## Clients

Targets live in `clients/<client>/`. Commercial-cloud workspaces are named `<client>-workspace-commercial`, in a file of the same name (`clients/<client>/<client>-workspace-commercial.yml`). All 41 use `tenant_id: d0544f30-7b82-4963-8cc7-04698b976ea1` (the managing tenant) and `allow_missing_mitre: true`.

| Client | Target | Resource group / workspace | Access | Rules selected | Pipeline verified |
|---|---|---|---|---|---|
| `client-01` | `client-01-workspace` | `rg-sentinel` / `law-sentinel-01` | Lighthouse | 1 | — |
| `client-02` | `client-02-workspace-commercial` | `rg-sentinel` / `law-sentinel-02` | Lighthouse | 1 | Yes |
| `client-03` | `client-03-workspace-commercial` | `rg-sentinel` / `law-sentinel-03` | In-tenant | 1 | Yes |
| `client-04` | `client-04-workspace-commercial` | `rg-sentinel` / `law-sentinel-04` | Lighthouse | 1 | Yes |
| `client-05` | `client-05-workspace-commercial` | `rg-sentinel` / `law-sentinel-05` | Lighthouse | 1 | Yes |
| `client-06` | `client-06-workspace-commercial` | `rg-sentinel` / `law-sentinel-06` | Lighthouse | 1 | Yes |
| `client-07` | `client-07-workspace-commercial` | `rg-sentinel` / `law-sentinel-07` | Lighthouse | 1 | Yes |
| `client-08` | `client-08-workspace-commercial` | `rg-sentinel` / `law-sentinel-08` | Lighthouse | 1 | Yes |
| `client-09` | `client-09-workspace-commercial` | `rg-sentinel` / `law-sentinel-09` | Lighthouse | 1 | Yes |
| `client-10` | `client-10-workspace-commercial` | `rg-sentinel` / `law-sentinel-10` | Lighthouse | 1 | Yes |
| `client-11` | `client-11-workspace-commercial` | `rg-sentinel` / `law-sentinel-11` | Lighthouse | 1 | Yes |
| `client-12` | `client-12-workspace-commercial` | `rg-sentinel` / `law-sentinel-12` | Lighthouse | 1 | Yes |
| `client-13` | `client-13-workspace-commercial` | `rg-sentinel` / `law-sentinel-13` | Lighthouse | 1 | Yes |
| `client-14` | `client-14-workspace-commercial` | `rg-sentinel` / `law-sentinel-14` | Lighthouse | 1 | Yes |
| `client-15` | `client-15-workspace-commercial` | `rg-sentinel` / `law-sentinel-15` | Lighthouse | 1 | Yes |
| `client-16` | `client-16-workspace-commercial` | `rg-sentinel` / `law-sentinel-16` | Lighthouse | 1 | Yes |
| `client-17` | `client-17-workspace-commercial` | `rg-sentinel` / `law-sentinel-17` | Lighthouse | 1 | Yes |
| `client-18` | `client-18-workspace-commercial` | `rg-sentinel` / `law-sentinel-18` | Lighthouse | 1 | Yes |
| `client-19` | `client-19-workspace-commercial` | `rg-sentinel` / `law-sentinel-19` | Lighthouse | 1 | Yes |
| `client-20` | `client-20-workspace-commercial` | `rg-sentinel` / `law-sentinel-20` | Lighthouse | 1 | Yes |
| `client-21` | `client-21-workspace-commercial` | `rg-sentinel` / `law-sentinel-21` | Lighthouse | 1 | Yes |
| `client-22` | `client-22-workspace-commercial` | `rg-sentinel` / `law-sentinel-22` | Lighthouse | 1 | Yes |
| `client-23` | `client-23-workspace-commercial` | `rg-sentinel` / `law-sentinel-23` | Lighthouse | 1 | Yes |
| `client-24` | `client-24-workspace-commercial` | `rg-sentinel` / `law-sentinel-24` | Lighthouse | 1 | Yes |
| `client-25` | `client-25-workspace-commercial` | `rg-sentinel` / `law-sentinel-25` | Lighthouse | 1 | Yes |
| `client-26` | `client-26-workspace-commercial` | `rg-sentinel` / `law-sentinel-26` | Lighthouse | 1 | Yes |
| `client-27` | `client-27-workspace-commercial` | `rg-sentinel` / `law-sentinel-27` | Lighthouse | 1 | Yes |
| `client-28` | `client-28-workspace-commercial` | `rg-sentinel` / `law-sentinel-28` | Lighthouse | 1 | Yes |
| `client-29` | `client-29-workspace-commercial` | `rg-sentinel` / `law-sentinel-29` | Lighthouse | 1 | Yes |
| `client-30` | `client-30-workspace-commercial` | `rg-sentinel` / `law-sentinel-30` | Lighthouse | 1 | Yes |
| `client-31` | `client-31-workspace-commercial` | `rg-sentinel` / `law-sentinel-31` | Lighthouse | 1 | Yes |
| `client-32` | `client-32-workspace-commercial` | `rg-sentinel` / `law-sentinel-32` | Lighthouse | 1 | Yes |
| `client-33` | `client-33-workspace-commercial` | `rg-sentinel` / `law-sentinel-33` | Lighthouse | 1 | Yes |
| `client-34` | `client-34-workspace-commercial` | `rg-sentinel` / `law-sentinel-34` | Lighthouse | 1 | Yes |
| `client-35` | `client-35-workspace-commercial` | `rg-sentinel` / `law-sentinel-35` | Lighthouse | 1 | Yes |
| `client-36` | `client-36-workspace-commercial` | `rg-sentinel` / `law-sentinel-36` | Lighthouse | 1 | Yes |
| `client-37` | `client-37-workspace-commercial` | `rg-sentinel` / `law-sentinel-37` | Lighthouse | 1 | Yes |
| `client-38` | `client-38-workspace-commercial` | `rg-sentinel` / `law-sentinel-38` | Lighthouse | 1 | Yes |
| `client-39` | `client-39-workspace-commercial` | `rg-sentinel` / `law-sentinel-39` | Lighthouse | 1 | Yes |
| `client-40` | `client-40-workspace-commercial` | `rg-sentinel` / `law-sentinel-40` | Lighthouse | 1 | Yes |
| `isi-enterprise` | `isi-enterprise-workspace-commercial` | `rg-sentinel` / `law-sentinel-41` | In-tenant | 57 | Yes |

"Rules selected" counts entries in the target's `rules:` list. For every client except `isi-enterprise`, that single entry is `rules/sentinel/testing/pipeline-connection-test.yml` with `overrides.enabled: false`. "Pipeline verified" marks targets where a preview and approved deployment have been confirmed; update this column as each client's connection test is run.

### Client notes

- Client names, tenant, subscription and workspace identifiers in this copy are synthetic placeholders.

| Setting | Value |
|---|---|
| Repository | `example-org/detection-as-code` |
| Target configuration | `clients/<client>/<client>-workspace-commercial.yml` |
| Preview environment | `sentinel-preview` (shared by all targets) |
| Production environment | `sentinel-production` (shared by all targets) |
| Deployment branch | `main` |
| Deployment trigger | Manual selection of target(s) and mode in GitHub Actions |

Tenant, subscription, resource group and workspace IDs are maintained in each target configuration. The target name selects a workspace; it is not the repository name.

## Access model

One pair of Azure applications in the ISI tenant serves every client. There are no per-client app registrations, federated credentials, GitHub environments or custom role definitions.

| Object | Purpose |
|---|---|
| `github-sentinel-lighthouse-preview` | Preview identity; one federated credential trusting `sentinel-preview` |
| `github-sentinel-lighthouse-deploy` | Deploy identity; one federated credential trusting `sentinel-production` |
| `sg-sentinel-pipeline-preview` | Holds the preview service principal |
| `sg-sentinel-pipeline-deploy` | Holds the deploy service principal |
| `sg-sentinel-detection-engineers` | Human read access for investigation |

Each group receives **built-in** roles at the client's Sentinel resource group:

| Group | Roles |
|---|---|
| `sg-sentinel-pipeline-deploy` | Microsoft Sentinel Contributor |
| `sg-sentinel-pipeline-preview` | Microsoft Sentinel Reader, Log Analytics Reader |
| `sg-sentinel-detection-engineers` | Microsoft Sentinel Reader, Reader |

**In-tenant clients** (`isi-enterprise`, `client-03`) get those roles as direct assignments at resource-group scope. **Client-owned tenants** (the other 39) get them through an Azure Lighthouse delegation, deployed once per client subscription.

### Why built-in roles

Lighthouse authorizations accept built-in roles only; custom role definitions cannot be delegated. Rather than run two access models, the in-tenant clients were migrated to built-in roles as well and their per-client custom roles removed.

The accepted tradeoff: `Microsoft Sentinel Contributor` is broader than the retired writer role and includes delete on Sentinel content in that workspace. It does not grant RBAC write, Entra access, workspace deletion, table purge, or access to other resources in the subscription. The compensating controls are that nothing reaches a client except through a merged commit with a what-if artifact and an approval record, and that `sentinel-production` requires a reviewer.

### Credential scoping

Federated credentials are **environment-scoped** to the two shared environments. Entra caps federated credentials at 20 per app, so per-client environments could not scale; two fixed environments need two credentials in total, regardless of client count.

Consequence: preview/deploy separation comes from which client ID the workflow passes plus group membership, rather than Entra enforcing it per client. GitHub's approval gate on `sentinel-production` remains the control that matters.

**Known gap:** `sentinel-production` currently has a single reviewer who can approve their own deployments. With 41 client workspaces behind that gate, a second reviewer and prevent-self-review are needed before this is business as usual.

### Lighthouse delegation

One delegation per client subscription, deployed at subscription scope from within the client's tenant. Requires Owner or User Access Administrator there — a Sentinel role or Contributor alone is not sufficient, because creating a delegation is a role assignment in the client's directory.

Under this model a target file's `tenant_id` is the **managing** tenant (`d0544f30`), not the client's. The workflow authenticates against ISI's tenant and the delegated subscription is visible from there. Putting the client's tenant ID in that field makes login fail in a way that does not point at the cause.

Confirmed by deployment: `Microsoft Sentinel Contributor` does carry `Microsoft.Resources/deployments/*` against a Lighthouse-delegated subscription. No fallback to `Contributor` at resource-group scope was needed.

## How the pipeline works

1. **Author:** create or edit YAML rules in a working branch using GitHub's website.
2. **Select:** add the exact rule path to the intended workspace's target configuration.
3. **Review:** open a pull request and pass offline validation.
4. **Merge:** merge the approved change into main.
5. **Preview:** run a Sentinel workflow in preview mode and inspect the proposed changes.
6. **Deploy:** start a deploy-mode run, review its fresh preview, and obtain production approval.
7. **Activate:** initially deploy new rules disabled; enable them through another reviewed deployment after functional testing.

**A merge does not automatically deploy to any client.** Each rollout explicitly selects one target, a list of targets, or *All enabled clients*.

Deploy mode previews and deploys the same generated bundle from the same commit. Without a `rule_path`, it applies all rules selected for that target, not just files changed in the latest pull request.

## Repository structure

```text
.github/
  workflows/
    ci.yml
    convert-sentinel-export.yml
    inspect-oidc.yml
    new-rule-id.yml
    sentinel.yml
    sentinel-multi-workspace.yml
    sentinel-workspace.yml
    sentinel-full-check.yml
  dependabot.yml
  pull_request_template.md

clients/
  <client>/<client>-workspace-commercial.yml   # 41 targets, listed above

rules/
  sentinel/
    aws/ endpoint/ health/ identity/ lastpass/
    testing/ threat-intelligence/

imports/
  isi-sentinel-export/          # raw portal exports used by the converter

scripts/
  rules.py
  pipeline.py
  cloud.py
  target_matrix.py
  sync_target_choices.py
  convert_sentinel_export.py
  migrate_export.py

templates/
  rule.yml

tests/
  test_pipeline.py
  test_target_selection.py
  test_selector_workflows.py
  test_convert_sentinel_export.py

docs/
  SOP-deploy-a-rule.md
  sentinel-rule-lifecycle-gitHub-sop.md
  azure-identities.md
  github-setup.md
  operations.md
  pilot-and-migration.md
  references.md
  scaling.md

roles/                          # obsolete — see below
requirements.txt
.gitignore
README.md
```

The `roles/` directory holding the four per-client custom role definitions is obsolete — those roles were deleted from both in-tenant subscriptions and cannot be delegated to client tenants. It should be removed.

YAML is the source of truth. GitHub Actions generates Azure deployment templates as run artifacts; authors do not manually build or commit generated ARM files.

### Rule library

60 rule files across seven folders:

| Folder | Rules |
|---|---|
| `aws/` | 5 |
| `endpoint/` | 7 |
| `health/` | 6 |
| `identity/` | 20 |
| `lastpass/` | 3 |
| `testing/` | 4 |
| `threat-intelligence/` | 15 |

`isi-enterprise-workspace-commercial` currently selects 57 of them; every other target selects only the connection test.

## Workflow reference

| Workflow | File | Purpose | Writes Sentinel rules? |
|---|---|---|---|
| **Sentinel CI** | `ci.yml` | Validates rule metadata, YAML, target selection, and supported overrides on push and PR | No |
| **Inspect Azure trust subject** | `inspect-oidc.yml` | Displays the issuer, audience, and subject needed for federated trust | No |
| **Generate rule ID** | `new-rule-id.yml` | Generates a GUID for a new detection | No |
| **Sentinel - select client or all clients** | `sentinel.yml` | Previews or deploys one client, or every enabled client, with an optional single `rule_path` | Only in deploy mode, after approval |
| **Sentinel - multiple workspaces** | `sentinel-multi-workspace.yml` | Up to eight client dropdowns (or *All enabled clients*) for one rollout | Only in deploy mode, after approval per target |
| **Sentinel - workspace worker** | `sentinel-workspace.yml` | Reusable per-target job (query check, preview, approve and deploy); called by the two workflows above, not run directly | Only in deploy mode |
| **Sentinel - full client query check** | `sentinel-full-check.yml` | Checks selected rules for enabled targets weekly or manually | No |
| **Sentinel - convert existing rule exports** | `convert-sentinel-export.yml` | Converts portal JSON exports under `imports/` into repository YAML | No |
| **Dependabot** | `dependabot.yml` | Proposes updates to GitHub Actions and Python dependencies through pull requests | No |

The full-check schedule is Monday at **06:00 UTC**. Its live scheduled execution still needs to be confirmed as an operational milestone.

Target selection is resolved by `scripts/target_matrix.py` before any cloud job starts. It fails fast on a misspelled, unknown, or disabled target, a duplicate dropdown selection, *All enabled clients* combined with other choices, or a target with no selected rules. When a `rule_path` is given, every requested target must already select that rule, so a client cannot receive a rule they did not select.

The multi-workspace workflow has eight client slots because GitHub caps `workflow_dispatch` at 10 inputs and `rule_path` and `mode` take two. The slot count is the `SLOTS` constant in `target_matrix.py`. For more than eight specific clients, run it in batches or use *All enabled clients*.

The client dropdowns are generated. When a target file is added, `scripts/sync_target_choices.py` rewrites the options between the `BEGIN GENERATED TARGET OPTIONS` markers; the onboarding app commits that change in the same PR as the new `workspace.yml`. Workflow files use CRLF line endings, and the sync script preserves them.

Concurrency is keyed per target, so runs for different clients proceed in parallel while a rerun for the same client serializes.

## Quick start: add a rule

1. For a new detection, run **Actions → Generate rule ID** and copy its GUID. Preserve the GUID when updating an existing rule.
2. Create a YAML file under the appropriate data-source folder, such as `rules/sentinel/endpoint/`, starting from `templates/rule.yml`.
3. Keep the rule's top-level `enabled: false` for initial deployment.
4. Add its exact path to the target's existing `rules:` list.
5. Open a PR, pass CI, obtain review, and merge.
6. Run **Sentinel - select client or all clients** with:

| Input | Preview run | Deployment run |
|---|---|---|
| Branch | `main` | `main` |
| Target | e.g. `client-04-workspace-commercial` | e.g. `client-04-workspace-commercial` |
| Rule path | optional — limits the run to one rule | same as preview |
| Mode | `preview` | `deploy` |

In preview mode, the production job should be **gray / Skipped**. In deploy mode, it should wait for the configured production reviewer before running.

Analysts working only in the browser should follow [SOP: Create and deploy a Sentinel detection rule](docs/SOP-deploy-a-rule.md). The [rule lifecycle SOP](docs/sentinel-rule-lifecycle-gitHub-sop.md) covers authoring, testing, approvals, activation, rollback, and troubleshooting.

### Example target selection

```yaml
rules:
  - path: rules/sentinel/testing/pipeline-connection-test.yml
    overrides:
      enabled: false
  - path: rules/sentinel/endpoint/bitlocker-encryption-not-enabled.yml
```

There must be only one `rules:` entry. Replace `rules: []` when populating the list. A line beginning with `#` is a comment and does not select a rule.

### Reading a preview's what-if

The artifact lists every resource in the target resource group. Most entries have `changeType: Ignore` — unrelated resources the deployment does not touch. A new rule should produce exactly one non-`Ignore` entry, of type `Create`. A `Delete`, or an `Update` on a rule you did not intend to change, is a reason to stop.

## Understand the enabled settings

| Setting | Effect |
|---|---|
| Target's top-level `enabled: true` | Allows pipeline operations for that workspace |
| Rule's top-level `enabled: false` | Deploys the detection in a disabled state |
| Rule's top-level `enabled: true` | Activates the detection after successful deployment |
| Assignment `overrides.enabled` | Overrides the rule's `enabled` for that one target |
| `groupingConfiguration.enabled: true` | Enables incident grouping; does not activate the detection |

A target override takes precedence over the shared rule, so a rollout to one client can control activation independently.

Setting the target to false does not disable a rule already running in Sentinel.

## Onboarding a new client

Per client, under the delegated model:

1. Obtain Owner or User Access Administrator on the client's subscription.
2. Register `Microsoft.ManagedServices` in that subscription if it is not already.
3. Deploy the Lighthouse delegation at subscription scope, granting the three ISI groups their built-in roles.
4. Confirm a registration **assignment** exists, not only a definition — a deployment can report success with nothing actually delegated.
5. Commit a target file with `tenant_id` set to the managing tenant, plus the regenerated workflow dropdowns.
6. Run preview, then an approved deploy, with the connection-test rule.

No app registrations, credentials, environments or role definitions are created. Steps 2–5 are automated by the companion onboarding app; step 1 is a human access-approval workflow (CyberQP JIT) and stays manual.

## Rule authoring conventions

- Use lowercase filenames with hyphens and exact matching paths.
- Keep existing rule IDs stable.
- Use ISO durations such as `PT6H` and `P7D`.
- Use `GreaterThan`, not `gt`.
- Indent multiline descriptions and KQL beneath `|`.
- Use ordinary KQL characters: `|` and `arg_max`, without Markdown escape backslashes.
- Keep custom-detail keys to **20 characters or fewer**. For example:
  `EncryptionStatus: EncryptionStatusString`.
- Use parent MITRE IDs in techniques; put sub-techniques in subTechniques with their parent also present.
- Missing MITRE metadata is currently permitted through `allow_missing_mitre: true`, which all 41 targets set. Track this exception and remove it once the selected rules have appropriate metadata.
- An unencrypted-device result is not, by itself, proof of malicious activity. Detection descriptions and classifications should reflect that distinction.

Client folder name, the `client:` field and the target prefix must agree. CI rejects a mismatch, which is what prevents a target file in one client's folder from pointing at another client's workspace.

## What successful checks mean

A green CI run confirms the implemented offline checks passed.

A green preview confirms query acceptance and a successful what-if request. It does not guarantee that Azure will accept every property during deployment; the custom-detail key-length issue demonstrated that distinction.

The automated query check returning no matching rows is a check on the query, not on coverage. Functional result review and scheduled rule-run verification are separate from the pipeline checks.

A green deployment confirms Azure reported success applying the selected bundle. It does not, by itself, prove the rule has executed successfully on its schedule or generated the expected incident.

## Next milestones

### 1. Complete operational acceptance

- [ ] Run the connection-test preview and approved deploy for the 35 newly onboarded targets, and record each in the client table.
- [ ] Confirm the resource-group names for `client-18` and `client-26`.
- [ ] Activate the BitLocker rule through a reviewed change when the detection owner approves.
- [ ] Confirm a scheduled evaluation succeeds after activation.
- [ ] Confirm actual alert severity, entities, custom details, and incident behavior.
- [ ] Document or complete the MITRE metadata exception.
- [ ] Verify the weekly full-client query-check workflow executes successfully.
- [ ] Perform and record a controlled rollback or disablement test.
- [ ] Decide whether to retain the disabled connectivity-test rule per client.
- [ ] Confirm required PR checks, code reviewers, and deployment reviewers reflect team policy.

### 2. Close out the access-model migration

- [ ] Add a second production reviewer and enable prevent-self-review.
- [ ] Remove the obsolete `roles/` directory.
- [ ] Write the access-model decision record: built-in roles, what Sentinel Contributor grants, compensating controls, and the branch-to-environment credential change.
- [ ] Decide whether the two in-tenant workspaces migrate to delegation or stay as direct assignments.
- [ ] Update tests and docs that still describe the retired per-client identity model.

### 3. Scale rule management

- [ ] Design a baseline rule set so a new shared rule does not require editing 41 target files.
- [ ] Decide how existing portal-managed rules in client workspaces are treated — imported, or left outside the repo.
- [ ] Raise `max-parallel` on the multi-workspace workflow, or batch rollouts, once throughput matters.
- [ ] Define a repeatable process for reviewing shared-rule changes across affected targets.

### 4. Improve long-term maintenance

- [ ] Add CI validation for custom-detail key lengths and other recurring deployment-time errors.
- [ ] Add a GitHub-visible post-deployment state check if the team needs automated enabled-state confirmation.
- [ ] Establish log/artifact retention and change-record requirements; current bundle retention is seven days.
- [ ] Review dependency-update PRs regularly.

## Operating boundaries

This repository provides separate deployment targets inside a shared MSSP-controlled repository. It does not provide separate code, log, or artifact visibility for each client. Keep access limited to authorized MSSP personnel.

The current implementation targets GitHub Enterprise Cloud and Azure public cloud. New client onboarding requires elevated access in the client's tenant; routine rule changes and deployment runs use GitHub's website.

Client workspaces typically contain many rules deployed outside this repository, from Content Hub or the portal. The pipeline manages only the rules a target explicitly selects; it is not a complete drift-auditing system, and full reapplication does not detect or remove unmanaged rules.

Deployments use Incremental mode. Removing a file or removing a target selection does **not** delete the live Sentinel rule. `Microsoft Sentinel Contributor` does permit rule deletion, so deletion is technically possible but is not performed by the pipeline.

When source files change, start a new workflow from the corrected main commit. Re-running failed jobs can reuse the earlier commit and bundle.

Running *All enabled clients* in deploy mode fans out to every enabled target. Use preview first, and prefer a `rule_path` so the run is limited to the rule being rolled out.

The pipeline uses custom GitHub Actions. Avoid configuring a competing content-deployment process to manage the same rules.

## Change records

For each rollout, retain the PR link, source commit, target, rule IDs, preview/deployment run links, approval, effective enabled state, and verification outcome.

For each client onboarding, retain the delegation deployment name, the registration assignment ID, and the target-file PR.

Update the client table and milestone sections as further clients and operational checks are confirmed.
