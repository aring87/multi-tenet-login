# GitHub configuration

The repository exists and is configured. This document records what that
configuration is, so it can be verified or rebuilt — it is not a setup walkthrough
for a new repository.

| Setting | Value |
|---|---|
| Repository | `example-org/detection-as-code` (private) |
| Default branch | `main` |
| Preview environment | `sentinel-preview` |
| Production environment | `sentinel-production` |

**Two environments serve every client.** Earlier versions of this pack created a
preview and a production environment per target. That model was retired: Entra caps
federated credentials at 20 per app, so per-client environments could not scale past
ten clients, and the per-client environments held the same two values anyway.

## The two environments

Both are created once and shared. Onboarding a client does **not** create an
environment — the onboarding tool verifies these exist and refuses to proceed if they
do not.

### `sentinel-preview`

- Environment variable `AZURE_CLIENT_ID` = the preview app's Application (client) ID
- No required reviewers. Preview is read-only and should not need an approval.
- Deployment branches restricted to `main`.

### `sentinel-production`

- Environment variable `AZURE_CLIENT_ID` = the deploy app's Application (client) ID
- **Required reviewers** — this is the gate that authorises every write to every
  client workspace.
- Prevent self-review, when a second reviewer is available.
- Deployment branches restricted to `main`.
- Disable administrator bypass of protection rules if policy requires it.

`AZURE_CLIENT_ID` is a **variable**, not a secret. The workflow reads it from
`vars.AZURE_CLIENT_ID`; placing it in `secrets` means the job finds nothing. Client
IDs are not sensitive.

Creating an environment alone protects nothing. The job must declare it, which
`sentinel.yml` does as a literal name on the `preview` and `deploy` jobs.

**Current gap:** `sentinel-production` has a single reviewer who can approve their own
deployments. That is the accepted compensating control for running the broader
`Microsoft Sentinel Contributor` role, so it needs a second reviewer before this is
routine operation.

## Branch protection

In **Settings → Rules → Rulesets**, an active branch ruleset targeting `main`:

- Require a pull request before merging.
- Require at least one approval.
- Dismiss stale approvals when changes are pushed.
- Require conversation resolution.
- Require the status check from the **Offline lint and target validation** job.
- Require the branch to be up to date before merging.
- Block force pushes and deletion.
- Keep bypass access restricted to a documented emergency process.

Select the actual check name GitHub offers in the picker; if it is absent, run the
workflow once so GitHub learns it.

Review who may approve changes, and in particular who may change workflow files. A
change to `.github/workflows/sentinel.yml` alters the deployment path for every
client and deserves more scrutiny than a rule edit.

## Workflows

| Workflow | Trigger | Writes to Sentinel? |
|---|---|---|
| Sentinel CI | push, pull request | No |
| Generate rule ID | manual | No |
| Inspect Azure trust subject | manual | No |
| Sentinel - selected workspace | manual dispatch, or called | Deploy mode only, after approval |
| Sentinel - multiple workspaces | manual dispatch | Deploy mode only, after approval per target |
| Sentinel - full client query check | Mondays 06:00 UTC, or manual | No |
| Dependabot | scheduled | No |

`Sentinel - multiple workspaces` calls the selected-workspace workflow through
`workflow_call`, so it inherits the two shared environments and needs no environment
configuration of its own. Each matrix leg queues for approval separately; the job
name identifies which client each pending approval belongs to.

Concurrency in `sentinel.yml` is keyed per target, so runs for different clients
proceed in parallel while a rerun for the same client serialises.

## Verifying the configuration

```bash
gh api "repos/example-org/detection-as-code/environments" --jq '.environments[].name'
```

Should return exactly `sentinel-preview` and `sentinel-production`. Any
`<target>-preview` or `<target>-production` entries are leftovers from the retired
model and should be removed.

```bash
gh variable list --env sentinel-preview --repo example-org/detection-as-code
gh variable list --env sentinel-production --repo example-org/detection-as-code
```

Each should show one variable, `AZURE_CLIENT_ID`, and the two values should differ.

## Access

Keep repository access limited to authorised MSSP personnel. This repository does not
provide separate code, log or artifact visibility per client — a reader sees every
client's target configuration and every deployment log. If a client needs repository
visibility, that requires a separate repository or a different delivery boundary.

[GitHub environment protection](https://docs.github.com/en/actions/how-tos/deploy/configure-and-manage-deployments/manage-environments)
· [OIDC with Azure](https://docs.github.com/en/actions/how-tos/secure-your-work/security-harden-deployments/oidc-in-azure)
