# Preview, deploy, and operate

## A normal change

Edit a shared YAML rule or a client's rule selection through GitHub's pencil editor
on a branch. Open a PR, review which targets select that rule, and wait for CI. Merge
approved changes to main.

Merging does not deploy to any client. This intentionally keeps rollout explicit.

Go to **Actions → Sentinel - selected workspace → Run workflow**:

- Branch: `main`
- Target: the exact target ID, for example `client-04-workspace`
- Rule path: optional; blank deploys every rule that target selects
- Mode: `preview`, or `deploy`

Preview mode compiles the selected rules, checks them against the real workspace, and
creates a what-if artifact. It does not write analytics rules.

Deploy mode performs those same steps, then waits for approval on
`sentinel-production`. Review the target, commit, bundle digest, and what-if artifact
in that run before approving. The deploy job consumes that exact bundle; it does not
rebuild from a later main commit.

A separate preview-only run is useful for planning but is not the artifact deployed by
a later deploy run. Each deploy run produces its own preview.

### Target resolution

The `prepare` job resolves the requested target against the committed target files
before anything else runs. A misspelled target fails immediately and prints the list
of valid target names. A target whose file has `enabled: false` also fails, with that
stated as the reason.

Both are safe failures — nothing has been built or authenticated at that point.

### Several clients at once

**Actions → Sentinel - multiple workspaces** fans one rule across an explicit list of
targets, comma separated, in preview or deploy mode.

Every target listed must already select that rule in its own target file. If one does
not, the whole run fails before doing anything — so a client never receives a rule
they did not select.

Each matrix leg queues for approval on the shared production environment separately.
The pending approvals are distinguished by job name, not by environment name.
`max-parallel` is 3, and concurrency is keyed per target, so different clients
proceed in parallel while a rerun for the same client serialises.

## Reading a what-if artifact

The artifact lists every resource in the target resource group, not only the rules
being deployed. Most entries show `changeType: Ignore` — unrelated resources the
deployment does not touch. Dozens of them is normal and not a warning sign.

Look at the entries where `changeType` is **not** `Ignore`:

| Change type | Means |
|---|---|
| `Create` | A rule not currently in the workspace. Expected for a new detection. |
| `Modify` | An existing rule is being updated. Confirm the rule ID is the one you intended. |
| `Delete` | Stop. The pipeline does not intend to delete rules; investigate before approving. |

## Queries and limitations

Offline CI checks metadata, YAML typing, identity duplication, target paths, and
overrides. It is not a complete KQL parser.

Live checks send the rule query followed by `| take 0` to the selected workspace with
a one-hour request timespan. They validate against real tables and functions and may
consume query resources, despite returning no rows. Multi-statement queries are
supported when their final expression can accept the appended pipe.

A one-hour probe is not a substitute for testing a rule's full production lookback.

Retired rules skip live query checks and must remain disabled. Disabled baseline rules
are still checked. What-if is predictive, not a guarantee; workspace state can change
while an approval is pending.

Client workspaces contain many rules deployed outside this repository, from Content
Hub or the portal. Nothing here audits or reconciles those.

## Weekly checks

The full-check workflow runs Mondays at 06:00 UTC and can be started manually. It
checks every selected non-retired rule in each enabled target using the preview
identity. One client's failure does not cancel other matrix jobs. It never invokes
production deployment.

Schedules are best effort. Its live scheduled execution is still an unconfirmed
operational milestone.

## Rollback

Revert the rule or target change through a new reviewed PR. After merging, run deploy
for the affected target and approve the resulting preview.

Keep the same rule ID when restoring a previous definition. Changing IDs may create
duplicates rather than updating the intended rule.

Deleting a YAML file or removing its target selection does not remove the live rule.
To retire a managed rule, keep it selected, set status retired and `enabled: false`,
then deploy.

Note a change from the earlier access model: the deploy identity now holds
`Microsoft Sentinel Contributor`, which **does** include rule delete. The pipeline
does not delete rules, but the permission is no longer absent. Deletion through an
authorised portal change, reconciled back into the repository, remains the documented
route.

For an urgent incident, an authorised responder may disable a rule in the portal and
then promptly reconcile the repository.

## Diagnostics

| Failure | Next check |
|---|---|
| Disabled or unknown target | Exact target ID and top-level `enabled` flag. The resolve-target step prints the valid names. |
| Missing YAML or query | The actual rule file at the exact path in the target's list, including capitalisation |
| Missing MITRE | Backfill tags, or the target's documented `allow_missing_mitre` exception |
| `AADSTS700213` on login | Credential subject must be the numeric-ID environment form. Use Inspect Azure trust subject. |
| Login succeeds, subscription not found | Target file has the client's tenant ID instead of the managing tenant |
| Wrong target deployed to | Workspace customer ID and subscription ID in the target file. Workspace and resource-group names collide across tenants; the GUIDs do not. |
| KQL rejected | Data connectors, parsers, watchlists, column names, query syntax |
| What-if authorisation | Preview group's role assignments or delegation, group membership in the token, and Azure CLI 2.76+ |
| Deployment authorisation | Deploy group's `Microsoft Sentinel Contributor` at the client's resource group, via assignment or delegation |
| `The content for this response was already consumed` | The CLI masking a 403. Check `deployments/write` reaches the scope. |
| No approval prompt | `sentinel-production` required reviewers and branch restrictions |
| Digest mismatch | Stop and inspect artifact integrity; do not bypass the check |
| Client's subscription missing from a delegated session | Delegation cached in the token. `az account list --all --refresh`, or sign out and in. Confirm a registration *assignment* exists, not only a definition. |
| `recently deleted ... allow some time` | Rule GUID tombstoned by an earlier manual portal deletion. Wait, or issue a new GUID. |

Do not rerun an old approved deployment casually: it can restore an older commit.
Start a fresh run from the reviewed main state unless performing an intentional
rollback.

GitHub may replace an older pending run with a newer one; every intermediate commit
is not guaranteed a deployment.

## What a green result does and does not establish

| Check | Establishes | Does not establish |
|---|---|---|
| Sentinel CI | Metadata, YAML structure, target selections and overrides pass the implemented checks | Complete Azure schema validity, or effective detection logic |
| Live query check | The query is accepted against that workspace under the preview identity | That it identifies the intended devices or users |
| What-if | Azure's predicted changes for the generated template | That the later deployment is guaranteed to succeed |
| Deploy job | Azure reported success applying the bundle | That the rule has executed on its schedule or created an incident |

The custom-detail key-length failure demonstrated the third distinction: a green
preview, then a rejected deployment.

Do not describe a green pipeline as proof of detection effectiveness.
