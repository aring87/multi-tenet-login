# Import rules and onboard the first workspace

## What the supplied files contain

Your inventory records 69 entries: 60 Scheduled, 2 NRT, 1 Fusion, and 6 MicrosoftSecurityIncidentCreation rules. The 62 query-based entries are candidates for this compiler. Fusion and MicrosoftSecurityIncidentCreation remain portal-managed.

The inventory has no query or ArmTemplate column. It cannot recreate your detections. The supplied yaml_rule_template is an authoring template, not a live rule.

## Bring in actual definitions

Since the repository files were deleted, first follow [the recovery guide](00-recovery-and-existing-setup.md). The handoff identifies a deployed firewall rule that is not fully defined in the supplied inventory. Do not reconstruct its query from its name.

**Preferred:** upload your previous `rules/sentinel/` YAML files into this repository through a new branch and PR.

**Alternative:** upload the rich legacy export CSV containing an `ArmTemplate` column under imports, merge it, and run **Actions → Convert legacy rule export**. This converter expects each ArmTemplate value to be the resource object used by your old exporter, with a literal GUID name. It does not accept an ordinary inventory CSV or a full parameterized ARM deployment template.

Download the generated artifact, inspect its migration report, and upload its rules folder through a new PR. It preserves recognized rule settings and enabled states. Unknown properties fail for review instead of being silently discarded. System template-lineage fields are not carried into YAML.

Do not upload the old generated `detections/` folder. ARM is now built in each run and downloaded as an artifact; no bot writes generated files back to your PR.

## Configure the pilot target

Edit `clients/client-a/workspace.yml`:
- Keep the target disabled while configuring it.
- Replace tenant ID, subscription ID, resource group, workspace name, and workspace customer ID with actual identifiers from Azure.
- Select one reviewed rule using its exact YAML path.
- Use an ID override when the target workspace already has a different GUID for the same detection.
- Use `enabled: false` in the override for a new disabled pilot if appropriate. Do not unexpectedly disable an existing production detection.
- The handoff says the original 62 migrated rules still need MITRE backfill. Set `allow_missing_mitre: true` on the original pilot target while importing those rules, document the exception, and remove it after backfill. The shipped disabled example remains strict until you make that choice. This exception does not allow malformed technique IDs.

Example selection:

```yaml
rules:
  - path: rules/sentinel/entra/suspicious-sign-ins.yml
    overrides:
      id: REPLACE_WITH_EXISTING_RULE_GUID
      enabled: false
      severity: Medium
```

The ID above is a placeholder and will fail validation until replaced. Omit the id override to use the library rule ID. Never invent a new ID when intending to update an existing rule.

## Cut over one writer

Before the first deployment, disable the old workflow for this workspace using its Actions menu, and document the cutover. If another Sentinel repository connection or process manages these rules, stop that competing writer before proceeding.

The new pack does not disable or modify any existing live workflow automatically.

After identities, environment approvals, rule definitions, and target mappings are reviewed, set the target's top-level enabled to true in a PR.

## Pilot acceptance

- [ ] PR lint and target selection pass.
- [ ] Selected tenant, subscription and workspace customer ID match Azure.
- [ ] Preview uses the preview identity and resolves queries.
- [ ] What-if shows only the intended rules and identities.
- [ ] Deploy mode pauses for the production reviewer.
- [ ] The approved deployment updates the expected rule.
- [ ] Other client/workspace rules remain unchanged.
- [ ] An authorized run still works after the setup JIT session expires.
- [ ] Rollback procedure and ownership are documented.
