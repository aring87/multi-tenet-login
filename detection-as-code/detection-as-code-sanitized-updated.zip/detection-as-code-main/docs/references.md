# Official references

## GitHub

- [OIDC with Azure](https://docs.github.com/en/actions/how-tos/secure-your-work/security-harden-deployments/oidc-in-azure)
- [Environment protection rules](https://docs.github.com/en/actions/how-tos/deploy/configure-and-manage-deployments/manage-environments)
- [OIDC subject claim customisation](https://docs.github.com/en/actions/how-tos/secure-your-work/security-harden-deployments/oidc-in-cloud-providers)
- [Azure login action](https://github.com/Azure/login)
- [upload-artifact](https://github.com/actions/upload-artifact) · [download-artifact](https://github.com/actions/download-artifact)

## Azure Lighthouse

- [Delegated resource management architecture](https://learn.microsoft.com/en-us/azure/lighthouse/concepts/architecture)
- [Onboard a subscription by ARM template](https://learn.microsoft.com/en-us/azure/lighthouse/how-to/onboard-customer)
- [Tenants, roles and users](https://learn.microsoft.com/en-us/azure/lighthouse/concepts/tenants-users-roles) — including which roles can be delegated
- [Cross-tenant management experiences](https://learn.microsoft.com/en-us/azure/lighthouse/concepts/cross-tenant-management-experience)

Custom role definitions cannot be delegated through Lighthouse. This constraint is
why the pipeline uses built-in roles.

## Azure RBAC and Sentinel

- [Microsoft Sentinel roles and permissions](https://learn.microsoft.com/en-us/azure/sentinel/roles)
- [Azure built-in role definitions](https://learn.microsoft.com/en-us/azure/role-based-access-control/built-in-roles)
- [Log Analytics access control](https://learn.microsoft.com/en-us/azure/azure-monitor/logs/manage-access)
- [Analytics-rule API fields, including separate techniques and subTechniques](https://learn.microsoft.com/en-us/azure/templates/microsoft.securityinsights/2023-12-01-preview/alertrules)

## Deployment

- [What-if and validation levels](https://learn.microsoft.com/en-us/azure/azure-resource-manager/templates/deploy-what-if)
- [Subscription-scope deployments](https://learn.microsoft.com/en-us/azure/azure-resource-manager/templates/deploy-to-subscription)
- [Resource provider registration](https://learn.microsoft.com/en-us/azure/azure-resource-manager/management/resource-providers-and-types)

## Entra

- [Workload identity federation](https://learn.microsoft.com/en-us/entra/workload-id/workload-identity-federation)
- [Federated credential considerations and limits](https://learn.microsoft.com/en-us/entra/workload-id/workload-identity-federation-considerations) — the 20-per-app cap that drives the two-environment model
- [Cross-tenant access settings](https://learn.microsoft.com/en-us/entra/external-id/cross-tenant-access-overview) — a client's outbound policy can block CLI sign-in into the managing tenant

---

The YAML source schema, explicit per-target rule selection, the two-environment
model, and per-target overrides are conventions implemented by this pack rather than
Azure or GitHub features.
