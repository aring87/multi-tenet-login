# Add a client or another workspace

## What onboarding costs now

Per client: **one delegation and one target file.** Nothing else.

No app registrations, no federated credentials, no GitHub environments, no custom role
definitions, no per-client variables. Those were all per-client under the earlier
model and are now fixed, shared objects — see the Azure identity guide.

| Step | Where | Automated? |
|---|---|---|
| 1. Obtain Owner or User Access Administrator on the client's subscription | Client tenant, via JIT/PIM | No — human approval workflow |
| 2. Register `Microsoft.ManagedServices` | Client subscription | Yes |
| 3. Deploy the Lighthouse delegation at subscription scope | Client tenant | Yes |
| 4. Confirm a registration *assignment* exists | Client subscription | Yes |
| 5. Read the workspace's four identifiers | From ISI's tenant, once delegated | Yes |
| 6. Commit a target file | This repository | Yes — opens a PR |
| 7. Preview, then an approved deploy, with the connection-test rule | GitHub Actions | No — deliberate |

Steps 2 through 6 are handled by the onboarding tool. Step 1 stays manual by design.
Step 7 stays manual because it is the reviewed deployment.

Realistically fifteen to twenty minutes per client, most of it waiting for access.

## Target files

`clients/<slug>/workspace.yml`, with target `<slug>-workspace`.

The client folder name, the `client:` field and the target prefix must all agree. CI
rejects a mismatch, which is what stops a target file in one client's folder from
pointing at another client's workspace.

One target always means one tenant, one subscription, one resource group, and one
workspace.

A second workspace for the same client is a second target file —
`clients/<slug>/workspace-<label>.yml`, target `<slug>-<label>`. The delegation is per
*subscription*, so a second workspace in an already-delegated subscription needs no
new delegation, only the new target file.

**`tenant_id` is the managing tenant** (`d0544f30`), not the client's, for every
target. See the Azure identity guide for why.

`isi-enterprise-primary` predates this convention. It works; aligning it is on the
milestone list.

## In-tenant versus delegated

A workspace inside the ISI tenant cannot be delegated — a subscription cannot be
delegated to the tenant it already lives in. Those clients get the same built-in
roles assigned directly to the three groups at resource-group scope.

Both cases produce identical access for the pipeline, and identical target files. The
difference is only in how that access was granted.

## Shared rules and client differences

Common YAML rules are referenced by exact path. A library change affects each
selecting target's next rollout; it does not automatically deploy to any of them.

Allowed overrides:

- `id` — preserve an existing rule's GUID in this workspace
- `enabled` — client-specific enablement
- `severity`
- `queryFrequency` and `queryPeriod` for Scheduled rules
- `triggerThreshold` for Scheduled rules
- `createIncident`

Query overrides are deliberately not allowed. If a client needs distinct query logic,
create a separately named YAML rule with its own library ID and select it for that
target.

The same library ID can be used in different workspaces because rule resource IDs
include the workspace. Within a target, effective IDs must be unique.

## The open scaling problem

**Adding a shared rule to every client currently means editing every client's target
file.** At four clients that is tolerable. At 150 it is not, and retrofitting a
solution across 150 files is worse than designing one now.

Options not yet decided:

- A baseline rule set that targets inherit, with target files listing only additions
  and exclusions.
- A tier concept — standard, enhanced — mapping to rule sets.
- Generated target files, with the rule selection held elsewhere.

This should be settled before client ten. Whoever picks it up should know that the
explicit per-target selection is deliberate and valuable: it is what guarantees a
client receives only what was chosen for them, and `Sentinel - multiple workspaces`
refuses to run against a target that has not selected the rule. Any inheritance
design has to preserve that property.

## Rollout discipline

There is no "deploy all" button. Roll a reviewed shared change out with
`Sentinel - multiple workspaces`, naming the targets explicitly, in preview mode
first.

Every target named must already select the rule, or the run fails before doing
anything.

`max-parallel` is 3. At roughly a minute per leg that is about an hour of wall time
for 150 clients, so batching or raising the limit is worth doing once throughput
matters — but not before the model has more clients on it.

Weekly validation covers all enabled targets regardless of rollout activity.

## Client workspaces are not empty

Every client onboarded so far had a substantial existing rule set — 161 and 227 rules
respectively — deployed from Content Hub or the portal, outside this repository.

The pipeline manages only the rules a target explicitly selects. It is not a drift
auditing system, and full reapplication neither detects nor removes unmanaged rules.

Whether that existing coverage gets imported into the repository or left as
portal-managed is an open decision, and it affects what "managed by detection as
code" means when reported to a client.

## Approval scope as client count grows

All clients share one production approval gate. One approval decision covers a
deployment to one client, but the same reviewers cover all of them.

If approvals ever need to differ by client — a contractual named approver, say — the
options are a small number of environments grouped by approval tier rather than one
per client. Returning to one environment per client would reintroduce the credential
cap problem.
