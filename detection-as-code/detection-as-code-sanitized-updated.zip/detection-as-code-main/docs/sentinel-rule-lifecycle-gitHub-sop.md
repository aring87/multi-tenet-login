# SOP: Create, Test, Approve, and Deploy Sentinel Rules Using GitHub

| Document field | Value |
|---|---|
| Version | 1.1 |
| Prepared | September 23, 2026 |
| Audience | Detection authors, reviewers, and deployment approvers |
| Repository | example-org/detection-as-code |
| Pilot target | isi-enterprise-primary |
| Operating interface | GitHub website only |
| Scope | Existing, onboarded Sentinel workspaces |
| Process owner | Security Engineering — confirm your internal owner |
| Status | Prepared for team adoption; verify current repository settings |

## Contents

- [1. Purpose and boundaries](#1-purpose-and-boundaries)
- [2. Responsibilities](#2-responsibilities)
- [3. Files and names used in this procedure](#3-files-and-names-used-in-this-procedure)
- [4. Before starting](#4-before-starting)
- [5. Generate an ID for a new rule](#5-generate-an-id-for-a-new-rule)
- [6. Create a working branch using GitHub](#6-create-a-working-branch-using-github)
- [7. Create the rule YAML](#7-create-the-rule-yaml)
- [8. Select the rule for the client workspace](#8-select-the-rule-for-the-client-workspace)
- [9. Open and review the pull request](#9-open-and-review-the-pull-request)
- [10. Complete CI and merge](#10-complete-ci-and-merge)
- [11. Run a preview from main](#11-run-a-preview-from-main)
- [12. Review the preview evidence](#12-review-the-preview-evidence)
- [13. Start deployment with the rule disabled](#13-start-deployment-with-the-rule-disabled)
- [14. Record deployment completion](#14-record-deployment-completion)
- [15. Activate the reviewed detection](#15-activate-the-reviewed-detection)
- [16. Update an existing rule](#16-update-an-existing-rule)
- [17. Disable or roll back through GitHub](#17-disable-or-roll-back-through-github)
- [18. Troubleshooting](#18-troubleshooting)
- [19. Weekly checks](#19-weekly-checks)
- [20. Completion checklist](#20-completion-checklist)
- [21. Copyable change-record form](#21-copyable-change-record-form)
- [22. References](#22-references)

## 1. Purpose and boundaries

Use this procedure to author a YAML detection rule, select the client workspace that will receive it, complete automated checks, review proposed changes, deploy the rule disabled, and activate it through a second reviewed change.

All operator actions in this procedure use GitHub's website. No terminal, local Git, local Python installation, or manual ARM build is required. GitHub Actions executes the pipeline's scripts.

This procedure assumes Azure identities, federated trust, permissions, GitHub environments, and branch protections are already configured for the selected workspace. Onboarding a new workspace is a separate administration task.

### What “tested” means

The current pipeline provides several different checks:

| Check | What it establishes | What it does not establish |
|---|---|---|
| Sentinel CI | Rule metadata, YAML structure, target selections, and supported overrides pass the implemented checks | Complete Azure schema validity or effective detection logic |
| Live query check | The query is accepted against the selected workspace under the preview identity | That the query identifies the intended devices or users |
| What-if | Azure's predicted changes for the generated deployment template | That the later deployment is guaranteed to succeed |
| Successful deploy job | Azure reported successful application of the bundle | That scheduled rule execution or incident creation has been observed |

The live query check appends `| take 0` and returns no matching records. Its request uses a one-hour timespan, which is not a substitute for testing a rule's full production lookback.

**GitHub does not currently display Sentinel's result simulation, actual matching rows, or scheduled rule-run health.** Record existing functional-test evidence in the pull request before activation. If that evidence is unavailable, complete the disabled deployment and keep the rule disabled until the detection owner validates behavior. Do not describe a green pipeline as proof of detection effectiveness.

## 2. Responsibilities

| Person | Responsibility |
|---|---|
| Author | Creates the rule, selects targets, explains expected behavior, and fixes failed checks |
| Code reviewer | Reviews query logic, identities, scope, scheduling, metadata, and rollback plan |
| Deployment operator | Starts the workflow for the correct target and commit |
| Production approver | Reviews that run's preview and authorizes or rejects the production job |
| Detection owner | Confirms functional-test evidence and readiness to activate |

Code approval and deployment approval are separate actions. A pull-request approval does not approve the production deployment. If prevention of self-review is enabled, someone other than the workflow initiator must approve production.

## 3. Files and names used in this procedure

| Item | Example |
|---|---|
| Shared endpoint rule | `rules/sentinel/endpoint/bitlocker-encryption-not-enabled.yml` |
| Client workspace configuration | `clients/isi-enterprise/workspace.yml` |
| Client value | `isi-enterprise` |
| Target value | `isi-enterprise-primary` |
| Preview environment | `isi-enterprise-primary-preview` |
| Production environment | `isi-enterprise-primary-production` |
| Main branch | `main` |

Use lowercase filenames with hyphens. The file path in a client's rule list must match the actual path exactly, including capitalization.

The target is a workspace selector, not the repository name. A client with another workspace receives another target and its own environments.

### Which enabled setting controls what?

| Location | Meaning | Initial value |
|---|---|---|
| Top-level `enabled` in client target YAML | Whether the pipeline may operate on this workspace target | `true` for an onboarded target |
| Top-level `enabled` in rule YAML | Whether Sentinel should run this detection | `false` for initial deployment |
| `groupingConfiguration.enabled` in rule YAML | Whether alerts are grouped into incidents according to the grouping configuration | As approved; does not activate the rule |

Setting the target to false does not disable already deployed Sentinel rules. It blocks operations through this pipeline for that target.

## 4. Before starting

Confirm the following through GitHub:

- [ ] You are in the correct private repository.
- [ ] The rule belongs to the intended client workspace.
- [ ] The target is already onboarded and its Azure identifiers are correct.
- [ ] The target's preview and production environments exist.
- [ ] Both environments restrict access to branch main.
- [ ] Production requires the designated reviewer.
- [ ] Your change will go through the required pull-request checks.
- [ ] A reviewer is available for the production approval.
- [ ] The proposed query's purpose, data requirements, and expected results are documented.
- [ ] The rule ID will be new for a new detection, or preserved for an existing detection.
- [ ] You know whether other targets select the same shared rule.

Use GitHub's repository search to search for the rule's exact path under `clients/`. Review all matches when changing a shared rule. A shared change affects each selecting target the next time that target is deployed.

Do not change workflow files, role definitions, client IDs, or Azure destinations as an incidental part of an ordinary rule change.

## 5. Generate an ID for a new rule

Skip this section when updating an existing rule.

1. Open the repository's **Actions** tab.
2. Select **Generate rule ID**.
3. Click **Run workflow**.
4. Select **main** and start the run.
5. Open the completed run.
6. Open its **Summary** and copy the value beside **New rule ID**.
7. Record the GUID in the change record.

A GUID identifies the rule resource. Renaming a file or display name does not require a new GUID.

For a rule already present in a client workspace, preserve its current GUID. If a shared library rule has a different ID, use the target's documented `overrides.id` field to preserve that client's existing resource identity. Changing an existing ID can create another rule rather than updating the intended one.

## 6. Create a working branch using GitHub

1. Open the **Code** tab.
2. Select **main** in the branch selector.
3. Open the branch selector again.
4. Enter a descriptive branch name, for example:
   `rule/bitlocker-encryption-not-enabled`
5. Choose the option to create that branch from main.
6. Confirm the new branch name is selected before editing.

Keep all related rule and target-selection changes on this branch. Do not merge an incomplete target selection that references a file not yet present.

If your organization uses a different branch naming convention, use that convention.

## 7. Create the rule YAML

1. From the repository root on the working branch, select **Add file → Create new file**.
2. Enter the complete path:
   `rules/sentinel/endpoint/bitlocker-encryption-not-enabled.yml`
3. Enter the rule definition.
4. Select **Commit changes**.
5. Use a clear message such as:
   `Add disabled BitLocker encryption detection`
6. Commit to the working branch.

For an existing YAML file on your computer, navigate into the intended repository folder and use **Add file → Upload files**. Confirm that it did not land in the repository root or inside an extra wrapper folder.

### Authoring template

Replace every placeholder before submitting the rule for deployment. The following is a structure example, not a functioning detection:

```yaml
# Generate a GUID using Actions > Generate rule ID.
# Preserve the existing GUID when updating an existing rule.
id: REPLACE_WITH_RULE_GUID
name: Replace with a descriptive detection name
description: |
  Explain what this rule detects and why it matters.
  Identify the required data sources.
  Describe known false positives and repeated-alert behavior.
owner: security-engineering
status: baseline

# Keep false for the initial deployment.
enabled: false
# Supported: Informational, Low, Medium, High.
severity: High
kind: Scheduled

# Example: run hourly against the previous hour.
# Adjust both values to match the detection.
queryFrequency: PT1H
queryPeriod: PT1H
triggerOperator: GreaterThan
triggerThreshold: 0

# Add justified MITRE classifications.
# Empty lists require an approved target exception.
tactics: []
techniques: []
# Optional: include the parent in techniques above.
# subTechniques:
#   - T1562.004

# Replace with tested KQL; indent every line by two spaces.
# Return each column used by mappings and custom details.
query: |
  REPLACE_WITH_TESTED_KQL

# OPTIONAL: remove entity blocks not supported by the query.
# Remove the whole section if no entities apply.
entityMappings:
  - entityType: Host
    fieldMappings:
      - identifier: FullName
        columnName: DeviceName
  - entityType: Account
    fieldMappings:
      - identifier: Name
        columnName: AccountName
      - identifier: UPNSuffix
        columnName: AccountUPNSuffix
  - entityType: IP
    fieldMappings:
      - identifier: Address
        columnName: IPAddress

# OPTIONAL: replace these examples or remove this section.
# Left: alert label, maximum 20 characters.
# Right: exact column returned by the query.
customDetails:
  DetectionReason: DetectionReason
  DeviceStatus: DeviceStatus

# Create incidents for alerts generated by this rule.
createIncident: true

# Controls incident grouping; does not activate the rule.
# Enable grouping only after reviewing its behavior.
groupingConfiguration:
  enabled: false
  reopenClosedIncident: false
  lookbackDuration: PT1H
  matchingMethod: AllEntities
  groupByEntities: []
  groupByAlertDetails: []
  groupByCustomDetails: []
```

Use approved metadata and behavior for the actual detection; do not retain placeholder values.

Entity mappings identify the accounts, hosts, and IP addresses in the query results for investigation. They do not create missing query columns or activate the detection. Keep entityMappings and customDetails at the top level, aligned with query and createIncident.

For an account such as alex@example.com, AccountName should contain alex and AccountUPNSuffix should contain example.com. Ensure your final query output includes both columns. Rename the columnName values if your query uses different names.

Remove any complete entity block whose columns are not returned by the query. For the BitLocker rule, omit the IP mapping unless the query returns an IP address. If no entities apply, remove the entire entityMappings section.

DetectionReason and DeviceStatus are example custom-detail columns, not values automatically supplied by Sentinel. Replace them with actual query columns or remove the customDetails section. Keep each left-hand label to 20 characters or fewer.

The one-hour schedule and grouping lookback are examples. Review the appropriate timing for each detection. Keep the new rule disabled through the first deployment, then activate it through a reviewed change after functional testing.

### Rule authoring checklist

- [ ] The top-level rule ID is a valid nonzero GUID.
- [ ] The display name is descriptive.
- [ ] The description is at least 20 characters and explains detection behavior.
- [ ] An owner and supported status are present.
- [ ] The new rule's top-level enabled value is false.
- [ ] Boolean values are unquoted true or false.
- [ ] Scheduled durations use ISO format, such as PT15M, PT6H, or P7D.
- [ ] queryPeriod is at least as long as queryFrequency.
- [ ] triggerOperator uses GreaterThan, LessThan, Equal, or NotEqual.
- [ ] The query is indented below query: |.
- [ ] Query pipes are plain |, not escaped \|.
- [ ] Functions use normal names such as arg_max, not arg\_max.
- [ ] MITRE classifications are justified by the detection's purpose.
- [ ] Parent techniques such as T1562 go in techniques.
- [ ] Sub-techniques such as T1562.004 go in subTechniques, with the parent also present.
- [ ] Each customDetails key is no more than 20 characters.
- [ ] Entity mappings reference columns actually returned by the query.
- [ ] Empty entityMappings are omitted when no mappings are needed.
- [ ] Incident settings use the source schema: top-level createIncident and groupingConfiguration.
- [ ] Unsupported fields such as a top-level version or incidentConfiguration are not added.

The implemented validator does not cover every Azure API constraint. A rule can pass CI or preview and still encounter a deployment-time validation error.

### Custom details example

The key on the left is the alert-detail label; the value on the right is the query column.

```yaml
customDetails:
  EncryptionStatus: EncryptionStatusString
```

Shortening the left-hand key does not require renaming the query column.

### Severity and repetition

Sentinel analytics-rule severity values are Informational, Low, Medium, and High. A query column containing a label such as Critical does not automatically change the actual alert severity.

A state-based query can report the same device repeatedly. For a six-hour schedule, expect up to four evaluations daily. A seven-day lookback can include older device reports. Review freshness, repetition, incident grouping, and expected alert volume before activation.

## 8. Select the rule for the client workspace

On the same working branch:

1. Open `clients/isi-enterprise/workspace.yml`.
2. Click the pencil to edit.
3. Locate the existing `rules:` entry.
4. Add the new rule's exact path.
5. Preserve other approved rule selections.
6. Keep the existing Azure identifiers unchanged.
7. Commit the change to the same working branch.

Example:

```yaml
rules:
  - path: rules/sentinel/testing/pipeline-connection-test.yml
  - path: rules/sentinel/endpoint/bitlocker-encryption-not-enabled.yml
```

If the file currently contains `rules: []`, replace that entry with the populated list. Do not leave both versions. Lines beginning with # are comments and do not select a rule.

At target level:

```yaml
enabled: true
allow_missing_mitre: true
```

Use allow_missing_mitre: true only when the target has an approved exception for missing tags. It applies to the selected set, not just one rule. It does not permit malformed technique IDs. Prefer false when the selected rules have complete approved metadata; do not invent classifications merely to satisfy CI.

### Optional client override

```yaml
rules:
  - path: rules/sentinel/endpoint/bitlocker-encryption-not-enabled.yml
    overrides:
      enabled: false
      severity: Medium
```

An override takes precedence over the shared rule value. If overrides.enabled remains false, changing the shared rule to true will not activate that target's copy.

Supported overrides in this pipeline are id, enabled, severity, queryFrequency, queryPeriod, triggerThreshold, and createIncident. Schedule/threshold fields apply to Scheduled rules. Query overrides are not supported.

## 9. Open and review the pull request

1. Open **Pull requests → New pull request**, or use **Compare & pull request**.
2. Set **base: main** and **compare: your working branch**.
3. Verify the changed files are the intended rule and client configuration.
4. Enter a descriptive title.
5. Complete the change description and checklist.
6. Select **Create pull request**.
7. Request review from the appropriate team member.

Include:

- Business or security reason.
- Rule ID and file path.
- Every potentially affected target.
- Target selected for this rollout.
- Data sources, tables, parsers, or watchlists needed.
- Expected matches and known false positives.
- Schedule, lookback, and repeated-alert behavior.
- Initial enabled state.
- Functional-test evidence or a statement that it remains outstanding.
- Any metadata exception.
- Rollback plan.

Do not paste passwords, tokens, or unnecessary raw client events into the PR.

### Reviewer checks

Open **Files changed** and confirm:

- The rule ID is correct and stable for an update.
- The query matches the stated purpose.
- The intended workspace alone is selected for this rollout.
- The rule will initially remain disabled.
- No unexpected Azure identifiers, overrides, or permissions changed.
- Custom-detail names and mappings are valid.
- Grouping and incident behavior are deliberate.
- The author has identified other clients selecting this shared rule.

## 10. Complete CI and merge

The **Sentinel CI** workflow should run automatically for the PR.

1. Open the PR's checks.
2. Find **Offline lint and target validation**.
3. Open its details if it fails.
4. Expand the red step and read the specific error.
5. Fix the source on the same branch.
6. Commit the fix; checks should run again.
7. Obtain required review after the final change.
8. Merge into main only when required checks pass.
9. Record the merged commit link or SHA.

Examples of errors include duplicate YAML keys, mismatched client names, missing rule files, unsupported properties, duplicate rule IDs, or invalid metadata.

The client folder, client field, and target prefix must agree:

```text
clients/isi-enterprise/workspace.yml
client: isi-enterprise
target: isi-enterprise-primary
```

Merging does not deploy rules in this pipeline. Deployment is a separate manual action.

## 11. Run a preview from main

1. Open **Actions**.
2. Select **Sentinel - selected workspace**.
3. Click **Run workflow**.
4. Enter:

| Field | Value |
|---|---|
| Branch | main |
| Target | isi-enterprise-primary |
| Mode | preview |

5. Start the run.
6. Open it and confirm the selected commit is the merged change you intend to test.

If someone merged another change before you started the run, main may contain additional updates. Review the run's actual commit and complete selected bundle, not just your PR.

### Expected preview result

- Prepare/build succeeds.
- Query check and preview succeeds.
- Approve and deploy selected workspace is **gray / Skipped**.

Gray/skipped deployment is normal in preview mode. A yellow waiting-for-approval production job indicates deploy mode was used.

A preview run performs no analytics-rule deployment. Its Azure query checks still access the selected workspace.

## 12. Review the preview evidence

Open the run's **Summary** and job logs.

Confirm:

- Target and workspace name.
- Source commit.
- Bundle digest.
- Intended rule IDs.
- Expected changes in the What-if table.

For a new rule, expect Create for that rule. For an update, expect Modify or NoChange as appropriate. What-if may also display unchanged or ignored resources; inspect them rather than assuming every listed resource will be modified.

Stop if the preview predicts an unexpected rule ID, workspace, enablement change, or unrelated resource modification.

The pipeline previews and deploys all rules explicitly selected for the target. Existing test rules or other selected detections can therefore appear in the bundle.

### Artifacts

The run produces a bundle artifact containing:

- template.json — generated Azure resource definitions.
- bundle.json — target, commit, rule list, and integrity information.

A successful preview also produces a what-if artifact.

Artifacts are available in the run's Summary under **Artifacts**. The current workflow requests seven-day retention. Capture essential approval evidence in the PR or change record before artifacts expire.

The GitHub website provides artifact download, not a general inline JSON editor. Reading the downloaded JSON is optional when the run summary and logs provide sufficient review detail. Do not claim to have inspected details that are available only in an artifact you have not opened.

A separate preview-only run is planning evidence. A later deploy run creates and previews its own bundle.

## 13. Start deployment with the rule disabled

After a successful reviewed preview:

1. Open **Actions → Sentinel - selected workspace**.
2. Click **Run workflow**.
3. Select main.
4. Enter the same target.
5. Choose **deploy**.
6. Start the run.
7. Wait for its preparation and preview jobs.

The production job should wait for approval. Do not treat a previous preview as approval of the new run; check this run's commit and what-if evidence.

### Production approver procedure

1. Open the waiting workflow run.
2. Verify target, environment, source commit, and proposed changes.
3. Confirm the new rule's effective enabled setting is false.
4. Select **Review deployments**.
5. Select the intended production environment.
6. Add a comment referring to the reviewed change or ticket.
7. Choose **Approve and deploy**, or reject if anything is incorrect.

When self-review is prevented, the workflow initiator cannot approve the deployment. Use an authorized independent reviewer. Do not bypass configured protection rules.

### Expected result

The production login and deploy step complete successfully, and GitHub marks the job green.

At this point, Azure has reported successful deployment. A disabled rule is not expected to execute on its schedule or create incidents.

## 14. Record deployment completion

In GitHub, confirm that **Deploy the same bundle that was previewed** succeeded; a green preview alone is insufficient.

Record in the PR or change issue:

- Target.
- Rule path and ID.
- Commit deployed.
- Deployment run link.
- Approver.
- Effective enabled state.
- Date/time.
- Functional-validation status.
- Any outstanding work.

Use a completion statement such as:

> Disabled deployment succeeded for isi-enterprise-primary. Azure accepted the selected bundle. Functional detection validation is recorded separately and is required before activation.

A deployment can partially apply resources before failing. On a failed run, do not assume that no rule changed or that every rule changed. Escalate ambiguous partial-state questions to the platform owner rather than repeatedly approving reruns.

## 15. Activate the reviewed detection

Activate only after the detection owner accepts the rule's functional evidence and expected alert volume.

1. Create a new branch from main.
2. Change the rule's top-level enabled value to true.
3. Check for a conflicting target override.
4. Open a new PR explaining the activation.
5. Pass CI and obtain code approval.
6. Merge.
7. Run preview for the intended target.
8. Confirm the intended enablement change.
9. Run deploy and obtain production approval.
10. Record the successful activation run.

For a shared rule used by multiple clients, prefer a target-specific override when enabling only one client's copy:

```yaml
rules:
  - path: rules/sentinel/endpoint/bitlocker-encryption-not-enabled.yml
    overrides:
      enabled: true
```

Leave the shared source disabled if other clients have not approved activation. Review each target's effective setting.

The current GitHub workflow does not verify subsequent scheduled execution or alert delivery. Track that operational acceptance separately; do not close it merely because activation deployed successfully.

## 16. Update an existing rule

Follow the same branch, PR, CI, preview, and approval process.

Keep its GUID unless the change is intentionally creating a different rule. Explain the effect of changed query logic, severity, schedules, entity mappings, custom details, or grouping.

Updating a shared source does not immediately deploy it to every client, but every selecting target will receive the updated definition on its next deployment. List that impact in the PR.

Do not edit generated ARM files or workflow artifacts. The YAML and target configuration remain the source of truth.

## 17. Disable or roll back through GitHub

### Disable a rule

1. Create a branch.
2. Set the rule's effective enabled setting to false.
3. For a shared rule, use a target override if only one client should be disabled.
4. Pass CI, review, and merge.
5. Preview and deploy the affected target.
6. Record success.

Setting the client target enabled to false is not a way to disable a live rule.

### Roll back a bad change

1. Open the merged PR that introduced it.
2. Use **Revert** if GitHub offers the option.
3. Review the resulting PR and ensure it restores only the intended changes.
4. If Revert is unavailable, open the file's **History**, view the known-good revision, copy its contents, and restore them on a new branch through the GitHub editor.
5. Keep the existing rule ID.
6. Pass CI, approve, and merge.
7. Start a fresh preview and deployment from main.

A GitHub revert changes source files. Azure is not rolled back until the corrected definition is deployed.

### Removing a rule

Deleting a file or removing its selection does not delete the live Sentinel rule. This pipeline deliberately does not grant analytic-rule deletion.

For a GitHub-only retirement, deploy the rule disabled and optionally mark it retired while keeping it selected. Permanent removal requires the separate authorized platform-removal process; it cannot be completed with the current workflow alone.

## 18. Troubleshooting

| Symptom | Likely cause and GitHub action |
|---|---|
| Workflow missing | Check the file is under .github/workflows on main, with no extra uploaded folder |
| Client folder/client/target mismatch | Align the lowercase folder, client value, and target prefix |
| Duplicate rules key | Replace rules: [] rather than leaving it beside another rules: entry |
| Rule file not found | Match the selected path and filename exactly |
| Missing metadata | Add required owner/status fields and resolve the approved MITRE policy |
| Invalid duration | Use PT6H/P7D, not 6h/7d |
| Query syntax error | Check indentation, escaped characters, tables, columns, and comments in the source YAML |
| Custom field key too long | Shorten the customDetails key before the colon to 20 characters or fewer |
| AADSTS700213 | Escalate for checking the production/preview app, exact OIDC subject, issuer, and audience; do not change rule IDs |
| Authorization failure | Escalate role assignment/scope review; do not grant Owner as a quick fix |
| Production job gray/skipped | Expected for preview mode |
| Production job yellow/waiting | An authorized reviewer must review that run |
| Deployment succeeded but detection inactive | Check the rule's effective enabled setting, including target overrides |
| Unexpected Create for an existing detection | Check that its original rule GUID was preserved |
| No matching records shown in Actions | Expected: the automated query probe returns no rows |
| Rule still active after removing its file | Source deletion does not remove or disable the deployed rule |

### When to rerun

**Source changed:** start a new workflow run from main after the fix is merged. Re-running failed jobs can reuse the old bundle and old commit.

**Only external configuration changed:** a failed-job rerun may be appropriate if the original commit and bundle are still the intended release. Recheck the target and approval requirements.

**Deployment partially failed:** review the failure with the platform owner before rerunning. A failed run is not proof that no Azure resources changed.

## 19. Weekly checks

The **Sentinel - full client query check** workflow is scheduled for Mondays at 06:00 UTC and can also be run manually.

It checks selected non-retired rules for enabled targets using preview identities. It does not deploy or replace functional testing. Review failed runs for schema, parser, watchlist, data-access, or configuration issues.

Scheduled GitHub runs are best effort. Environments requiring preview approval can leave these checks waiting.

## 20. Completion checklist

### Disabled deployment complete

- [ ] Rule and target changes reviewed and merged.
- [ ] CI passed.
- [ ] Preview passed for the intended target.
- [ ] Same-run deployment preview reviewed.
- [ ] Production approved by an authorized reviewer.
- [ ] Actual deployment step succeeded.
- [ ] Effective rule setting is disabled.
- [ ] Run, commit, rule ID, and outcome recorded.

### Activation complete

- [ ] Detection owner accepted functional evidence and expected repeated results.
- [ ] Activation scope is correct for shared rules.
- [ ] Effective enabled value is true for the intended target.
- [ ] Activation PR passed review and CI.
- [ ] Activation preview and approved deployment succeeded.
- [ ] Post-activation execution/alert verification is separately tracked.
- [ ] Rollback ownership is documented.

## 21. Copyable change-record form

```text
Change title:
Author:
Code reviewer:
Production approver:

Rule name:
Rule GUID:
Rule path:
Target:
Other targets selecting this rule:

Purpose and data requirements:
Expected results:
Schedule and lookback:
Expected repeat-alert behavior:
Functional-test evidence:
Metadata exception, if any:

Initial enabled state:
Effective target overrides:
Rollback plan:

Pull-request link:
Merged commit:
Preview-run link:
Deployment-run link:
Approval:
Deployment outcome:
Activation status:
Remaining operational verification:
```

## 22. References

- [Review GitHub deployments](https://docs.github.com/en/actions/how-tos/managing-workflow-runs-and-deployments/managing-deployments/reviewing-deployments)
- [Download GitHub workflow artifacts](https://docs.github.com/en/actions/how-tos/manage-workflow-runs/download-workflow-artifacts)
- [Read workflow run logs](https://docs.github.com/en/actions/how-tos/monitor-workflows/use-workflow-run-logs)
- [Sentinel scheduled-rule behavior](https://learn.microsoft.com/en-us/azure/sentinel/scheduled-rules-overview)
- [Sentinel entity mapping reference](https://learn.microsoft.com/en-us/azure/sentinel/entities-reference)

This SOP describes the custom pipeline configured in this project. Verify it when workflows, target schemas, or organization approval policies change.
