# Sentinel Analytics exports for conversion

Upload the Microsoft Sentinel Analytics ARM JSON exports for **one workspace** into this folder on a working branch. Give each export a unique filename, such as `isi-rules-page-1.json`.

The converter read every `.json` file directly in this folder. Check that all intended rules are present, keep a separate backup of the original exports, and remove old exports before starting a different workspace import.

This README only creates and explains the import folder. It is not a rule and is not deployed.
