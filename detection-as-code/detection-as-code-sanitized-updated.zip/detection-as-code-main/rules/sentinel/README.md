# Shared YAML rule library

Store reviewed YAML rules under data-source folders such as `entra/`, `m365/`, and `endpoint/`. A rule is deployed only when a client workspace explicitly selects its path. No rules are selected automatically.

Start with the example in `templates/rule.yml.example`, or import your actual legacy YAML sources. Templates and inventory CSV files do not contain your full detection library.
