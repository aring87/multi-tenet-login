"""Runs only in protected, main-branch GitHub jobs after OIDC login."""
import argparse
import json
import os
import re
import subprocess
from pathlib import Path
from pipeline import verify_bundle

def az(*args):
    result = subprocess.run(["az", *args], capture_output=True, text=True)
    if result.returncode:
        # Keep stdout (query results) out of logs; retain Azure diagnostics for review.
        raise RuntimeError("Azure command failed: " + " ".join(args[:3]) +
                           " (exit " + str(result.returncode) + "). " + result.stderr.strip()[:2000])
    return result.stdout

def verify_target(target):
    config = target["azure"]
    account = json.loads(az("account", "show", "-o", "json"))
    if account["id"].lower() != config["subscription_id"].lower() or account["tenantId"].lower() != config["tenant_id"].lower():
        raise ValueError("Logged-in Azure tenant/subscription differs from selected target")
    ws = json.loads(az(
        "monitor", "log-analytics", "workspace", "show",
        "--subscription", config["subscription_id"],
        "--resource-group", config["resource_group"],
        "--workspace-name", config["workspace_name"], "-o", "json"
    ))
    expected_id = ("/subscriptions/" + config["subscription_id"] + "/resourceGroups/" +
                   config["resource_group"] + "/providers/Microsoft.OperationalInsights/workspaces/" +
                   config["workspace_name"])
    if ws["id"].lower() != expected_id.lower() or ws["customerId"].lower() != config["workspace_id"].lower():
        raise ValueError("Resolved workspace differs from selected workspace ID")

def probe(query):
    # Preserve multiline statements; remove a final terminator and optional comment.
    # This is a real Log Analytics request, not a complete local KQL parser.
    base = query.rstrip()
    base = re.sub(r";\s*(//[^\n]*)?$", "", base).rstrip()
    return base + "\n| take 0"

def query_checks(manifest, arm):
    config = manifest["target"]["azure"]
    for record, resource in zip(manifest["rules"], arm["resources"]):
        if record["status"] == "retired":
            print("Skipping retired rule query:", record["id"])
            continue
        print("Checking query schema for rule:", record["id"])
        az("monitor", "log-analytics", "query", "--workspace", config["workspace_id"],
           "--analytics-query", probe(resource["properties"]["query"]),
           "--timespan", "PT1H", "--output", "none")

def deployment_args(manifest, folder, operation):
    config = manifest["target"]["azure"]
    args = [
        "deployment", "group", operation,
        "--subscription", config["subscription_id"],
        "--resource-group", config["resource_group"],
        "--template-file", str(folder / "template.json"),
        "--parameters", "workspace=" + config["workspace_name"],
        "--mode", "Incremental",
    ]
    if operation in ("validate", "what-if"):
        args += ["--validation-level", "ProviderNoRbac"]
    if operation == "what-if":
        args += ["--no-pretty-print", "--output", "json"]
    else:
        args += ["--output", "none"]
    if operation == "create":
        # Stable within one run/attempt and below Azure deployment-name length limit.
        label = "sentinel-" + os.environ.get("GITHUB_RUN_ID", "local") + "-" + os.environ.get("GITHUB_RUN_ATTEMPT", "1")
        args += ["--name", label]
    return args

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("action", choices=["preview", "deploy", "query"])
    ap.add_argument("--bundle", default="build/bundle")
    args = ap.parse_args()
    if os.environ.get("GITHUB_REF") != "refs/heads/main":
        raise ValueError("Azure operations are allowed only from main")
    folder = Path(args.bundle)
    manifest, arm = verify_bundle(folder, os.environ.get("EXPECTED_BUNDLE_DIGEST", ""))
    target = manifest["target"]
    if target["target"] != os.environ.get("EXPECTED_TARGET"):
        raise ValueError("Selected target mismatch")
    if manifest["commit"] != os.environ.get("GITHUB_SHA"):
        raise ValueError("Bundle commit differs from workflow commit")
    if args.action == "deploy" and os.environ.get("DEPLOYMENT_MODE") != "deploy":
        raise ValueError("Deployment requires explicit deploy mode")
    version = json.loads(az("version", "--output", "json"))["azure-cli"]
    if tuple(int(x) for x in version.split(".")[:2]) < (2, 76):
        raise ValueError("Azure CLI 2.76+ is required for ProviderNoRbac preview")
    verify_target(target)
    if args.action in ("preview", "query"):
        query_checks(manifest, arm)
    if args.action == "preview":
        az(*deployment_args(manifest, folder, "validate"))
        text = az(*deployment_args(manifest, folder, "what-if"))
        # Full result is retained as a same-run artifact for the authorized reviewer.
        (folder / "what-if.json").write_text(text, encoding="utf-8")
        result = json.loads(text)
        if result.get("status") not in (None, "Succeeded") or result.get("error"):
            raise RuntimeError("Azure what-if did not succeed")
        if "GITHUB_STEP_SUMMARY" in os.environ:
            with open(os.environ["GITHUB_STEP_SUMMARY"], "a", encoding="utf-8") as stream:
                stream.write("## What-if: " + target["target"] + "\n\n")
                stream.write("| Change | Resource |\n|---|---|\n")
                for change in result.get("changes", []):
                    stream.write("| " + change.get("changeType", "?") + " | " +
                                 change.get("resourceId", "?").replace("|", "/") + " |\n")
                stream.write("\nReview the what-if artifact before approving deployment.\n")
    elif args.action == "deploy":
        az(*deployment_args(manifest, folder, "create"))
        print("Deployment succeeded for", target["target"], "at", manifest["commit"])
    else:
        print("Full selected-rule query check passed for", target["target"])

if __name__ == "__main__":
    main()
