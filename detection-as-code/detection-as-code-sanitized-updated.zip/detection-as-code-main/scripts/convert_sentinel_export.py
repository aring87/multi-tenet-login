"""Convert Sentinel ARM exports to reviewable pipeline YAML. Never deploys.

Python 3.11+ and PyYAML. See docs/import-existing-rules.md for GitHub UI steps.
"""
import argparse
import copy
import importlib.util
import json
import re
import sys
from collections import Counter
from pathlib import Path

import yaml

GUID = r"[0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{12}"
TYPES = {
    "microsoft.securityinsights/alertrules",
    "microsoft.operationalinsights/workspaces/providers/alertrules",
}
READ_ONLY = {"lastModifiedUtc"}
# Only query-based rules are converted. Other kinds (Fusion, Microsoft Security
# incident creation, ML behavior analytics, threat intelligence) are platform
# features without authored KQL; they are counted and reported, never converted.
MANAGED_KINDS = {"Scheduled"}
DIRECT = {
    "description", "enabled", "severity", "query", "queryFrequency", "queryPeriod",
    "triggerOperator", "triggerThreshold", "tactics", "techniques", "subTechniques",
    "entityMappings", "customDetails", "suppressionEnabled", "suppressionDuration",
    "eventGroupingSettings", "alertDetailsOverride", "alertRuleTemplateName",
    "templateVersion", "sentinelEntitiesMappings",
}


class Dumper(yaml.SafeDumper):
    pass


def represent_string(dumper, value):
    return dumper.represent_scalar("tag:yaml.org,2002:str", value,
                                   style="|" if "\n" in value else None)


Dumper.add_representer(str, represent_string)


def write_yaml(path, data):
    path.parent.mkdir(parents=True, exist_ok=True)
    text = yaml.dump(data, Dumper=Dumper, sort_keys=False, allow_unicode=True, width=120)
    if yaml.safe_load(text) != data:
        raise ValueError("YAML serialization changed the rule")
    path.write_text(text, encoding="utf-8")


def unique_object(pairs):
    result = {}
    for key, value in pairs:
        if key in result:
            raise ValueError("Duplicate JSON key: " + key)
        result[key] = value
    return result


def resource_id(resource, parameters=None):
    name = resource.get("name", "")
    parameters = parameters or {}
    if not isinstance(name, str):
        raise ValueError("Resource name is not a string")
    param = re.fullmatch(r"\[parameters\('([^']+)'\)\]", name, re.I)
    if param:
        name = parameters.get(param[1], {}).get("defaultValue", "")
    if not isinstance(name, str):
        raise ValueError("Rule-name parameter has no literal default")
    if not name.startswith("["):
        tail = name.rsplit("/", 1)[-1]
        if re.fullmatch(GUID, tail):
            return tail.lower()
    prefix = r"\[concat\(\s*parameters\('[^']+'\)\s*,\s*"
    patterns = [
        prefix + r"'/Microsoft\.SecurityInsights/(" + GUID + r")'\s*\)\]",
        prefix + r"'/Microsoft\.SecurityInsights/'\s*,\s*'(" + GUID + r")'\s*\)\]",
    ]
    for pattern in patterns:
        match = re.fullmatch(pattern, name, re.I)
        if match:
            return match[1].lower()
    raise ValueError("Cannot safely resolve existing rule GUID from resource name")


def unmanaged_name(resource, parameters=None):
    """Identify a rule the pipeline does not manage, for counting and reporting only."""
    try:
        return resource_id(resource, parameters)
    except (ValueError, TypeError, AttributeError):
        pass
    name = resource.get("name", "")
    if not isinstance(name, str):
        return "unresolved"
    match = re.search(r"/Microsoft\.SecurityInsights/'?\s*,?\s*'?([^'/\]]+)'?\s*\)\]$", name, re.I)
    if match:
        return match[1]
    return name.rsplit("/", 1)[-1] or "unresolved"


def extract_resources(document):
    if isinstance(document, dict) and isinstance(document.get("resources"), list):
        resources = document["resources"]
        parameters = document.get("parameters", {})
    elif isinstance(document, dict) and isinstance(document.get("value"), list):
        resources, parameters = document["value"], {}
    elif isinstance(document, list):
        resources, parameters = document, {}
    elif isinstance(document, dict) and "properties" in document:
        resources, parameters = [document], {}
    else:
        raise ValueError("Expected an ARM export with resources, a REST value list, or one rule")
    if not isinstance(parameters, dict):
        raise ValueError("Invalid ARM parameters")
    if any(not isinstance(item, dict) for item in resources):
        raise ValueError("Every resource must be an object")
    return resources, parameters


def candidate(resource, identity, owner):
    if resource.get("kind") != "Scheduled":
        raise ValueError("Unsupported rule kind: " + str(resource.get("kind")))
    props = resource.get("properties")
    if not isinstance(props, dict):
        raise ValueError("Missing rule properties")
    required = {"displayName", "enabled", "severity", "query", "queryFrequency",
                "queryPeriod", "triggerOperator", "triggerThreshold"}
    missing = required - props.keys()
    if missing:
        raise ValueError("Missing required properties: " + ", ".join(sorted(missing)))
    if type(props["enabled"]) is not bool:
        raise ValueError("enabled must be an exported boolean")
    if not isinstance(props["query"], str) or not props["query"].strip():
        raise ValueError("Missing KQL query")
    if not isinstance(props["displayName"], str) or not props["displayName"].strip():
        raise ValueError("Missing displayName")
    result = {"id": identity, "name": props["displayName"],
              "description": props.get("description", ""), "owner": owner,
              "status": "baseline", "kind": "Scheduled"}
    for key, value in props.items():
        # An exported null means "not set"; leave it out of the candidate YAML.
        if key in DIRECT and value is not None:
            result[key] = copy.deepcopy(value)
    result.setdefault("tactics", [])
    result.setdefault("techniques", [])
    techniques = result["techniques"]
    if isinstance(techniques, list) and all(isinstance(t, str) for t in techniques):
        subs = [t for t in techniques if re.fullmatch(r"T\d{4}\.\d{3}", t)]
        if subs:
            result["techniques"] = sorted(set(t.split(".")[0] for t in techniques))
            result["subTechniques"] = sorted(set(result.get("subTechniques", []) + subs))
    incident = props.get("incidentConfiguration")
    if isinstance(incident, dict):
        for key in ("createIncident", "groupingConfiguration"):
            if key in incident:
                result[key] = copy.deepcopy(incident[key])
    return result


def differences(expected, actual, path="properties"):
    if type(expected) is not type(actual):
        return [path + ": value/type differs"]
    if isinstance(expected, dict):
        changes = []
        for key in sorted(expected.keys() | actual.keys()):
            child = path + "." + key
            if key not in expected:
                changes.append(child + ": added by pipeline")
            elif key not in actual:
                changes.append(child + ": omitted by pipeline")
            else:
                changes.extend(differences(expected[key], actual[key], child))
        return changes
    if expected != actual:
        return [path + ": value differs"]
    return []


def normalize_properties(props):
    value = copy.deepcopy(props)
    for key in READ_ONLY:
        value.pop(key, None)
    # ARM treats an explicit null and an omitted optional property the same way.
    # Only top-level nulls are dropped; any real value is still compared strictly.
    for key in [k for k, v in value.items() if v is None]:
        value.pop(key)
    # The rule generator trims trailing whitespace from KQL; it does not change the query.
    if isinstance(value.get("query"), str):
        value["query"] = value["query"].rstrip()
    for key in ("tactics", "techniques", "subTechniques"):
        if isinstance(value.get(key), list):
            value[key] = sorted(value[key])
    return value


def check_round_trip(rule, resource, module):
    if module is None:
        return ["Current scripts/rules.py unavailable; deployment compatibility unverified"], []
    warnings = module.validate(copy.deepcopy(rule), allow_missing_mitre=True) or []
    generated = module.template([copy.deepcopy(rule)])
    resources = generated.get("resources", [])
    if len(resources) != 1:
        return ["Pipeline did not generate exactly one rule"], warnings
    deployed = resources[0]
    problems = []
    if str(deployed.get("type", "")).lower() not in TYPES:
        problems.append("Pipeline generated an unexpected resource type")
    if deployed.get("kind") != resource.get("kind"):
        problems.append("Pipeline changed the rule kind")
    if resource_id(deployed, generated.get("parameters", {})) != rule["id"]:
        problems.append("Pipeline changed the rule GUID")
    problems.extend(differences(normalize_properties(resource["properties"]),
                                normalize_properties(deployed.get("properties", {}))))
    return problems, list(warnings)


def load_pipeline(root):
    path = root / "scripts/rules.py"
    if not path.is_file():
        return None
    sys.path.insert(0, str(path.parent))
    spec = importlib.util.spec_from_file_location("sentinel_existing_rules", path)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def existing_ids(root):
    found = {}
    for path in sorted((root / "rules/sentinel").rglob("*")):
        if path.suffix.lower() not in {".yaml", ".yml"}:
            continue
        rule = yaml.safe_load(path.read_text(encoding="utf-8-sig"))
        if not isinstance(rule, dict) or not isinstance(rule.get("id"), str):
            raise ValueError("Cannot check existing rule ID: " + str(path))
        found.setdefault(rule["id"].lower(), []).append(path.relative_to(root).as_posix())
    return found


def convert(input_dir, out, root, owner="security-engineering", expected_count=68):
    if out.exists():
        raise ValueError("Output folder already exists; choose a fresh folder")
    files = sorted(input_dir.glob("*.json"))
    if not files:
        raise ValueError("No JSON exports found in input folder")
    if out.resolve().is_relative_to((root / "rules").resolve()):
        raise ValueError("Output must be outside the live rules library")
    module = load_pipeline(root)
    existing = existing_ids(root)
    records, input_errors = [], []
    for file in files:
        try:
            doc = json.loads(file.read_text(encoding="utf-8-sig"), object_pairs_hook=unique_object)
            resources, parameters = extract_resources(doc)
            if not resources:
                input_errors.append(file.name + ": export has no resources")
            for index, resource in enumerate(resources):
                record = {"source": file.name, "index": index, "resource": resource,
                          "id": None, "issues": [], "warnings": [], "unmanaged": False}
                try:
                    if str(resource.get("type", "")).lower() not in TYPES:
                        raise ValueError("Unsupported resource type; nested templates are not converted")
                    if resource.get("kind") not in MANAGED_KINDS:
                        record["unmanaged"] = True
                        record["id"] = unmanaged_name(resource, parameters)
                        records.append(record)
                        continue
                    record["id"] = resource_id(resource, parameters)
                except (ValueError, TypeError, AttributeError) as error:
                    record["issues"].append(str(error))
                records.append(record)
        except (ValueError, OSError) as error:
            input_errors.append(file.name + ": " + str(error))
    counts = Counter(r["id"] for r in records if r["id"])
    out.mkdir(parents=True)
    originals = out / "original-exports"
    originals.mkdir()
    for file in files:
        (originals / file.name).write_bytes(file.read_bytes())
    report, selection = [], []
    for number, record in enumerate(records, 1):
        identity, resource = record["id"], record["resource"]
        issues = record["issues"]
        if record["unmanaged"]:
            if counts[identity] > 1:
                issues.append("Duplicate rule across exports; all copies held for review")
            report.append({"source": record["source"], "resource_index": record["index"],
                           "id": identity, "kind": resource.get("kind"),
                           "name": (resource.get("properties") or {}).get("displayName") or identity,
                           "result": "needs-review" if issues else "unmanaged",
                           "output": None, "issues": issues, "warnings": []})
            continue
        if identity and counts[identity] > 1:
            issues.append("Duplicate GUID across exports; all copies held for review")
        if identity in existing:
            issues.append("GUID already exists in library: " + ", ".join(existing[identity]))
        rule = None
        if identity:
            try:
                rule = candidate(resource, identity, owner)
                problems, warnings = check_round_trip(rule, resource, module)
                issues.extend(problems)
                record["warnings"].extend(warnings)
            except Exception as error:
                issues.append("Conversion/compatibility check failed: " + str(error))
        if rule is not None:
            slug = re.sub(r"[^a-z0-9]+", "-", rule["name"].lower()).strip("-")[:65] or "rule"
            filename = slug + "-" + identity + ".yml"
            relative = "rules/sentinel/imported/" + filename
            if not issues:
                destination = out / "checked" / relative
                selection.append({"path": relative})
            else:
                destination = out / "needs-review" / (str(number) + "-" + filename)
            write_yaml(destination, rule)
            output_path = destination.relative_to(out).as_posix()
        else:
            output_path = None
        report.append({"source": record["source"], "resource_index": record["index"],
                       "id": identity, "kind": resource.get("kind"),
                       "result": "needs-review" if issues else "checked",
                       "output": output_path, "issues": issues, "warnings": record["warnings"]})
    unique_count = len(counts)
    if unique_count != expected_count:
        input_errors.append(f"Expected {expected_count} unique rule IDs; resolved {unique_count}")
    checked = sum(r["result"] == "checked" for r in report)
    unmanaged = sum(r["result"] == "unmanaged" for r in report)
    held = len(report) - checked - unmanaged
    summary = {"expected_rules": expected_count, "resource_count": len(records),
               "unique_rule_ids": unique_count, "checked": checked,
               "unmanaged": unmanaged, "needs_review": held, "input_errors": input_errors,
               "pipeline_round_trip_available": module is not None, "rules": report}
    (out / "conversion-report.json").write_text(json.dumps(summary, indent=2) + "\n", encoding="utf-8")
    write_yaml(out / "target-selection-fragment.yml", {"rules": selection})
    lines = ["# Sentinel conversion report", "",
             f"Expected: {expected_count}; unique IDs: {unique_count}; checked: {checked}; "
             f"unmanaged: {unmanaged}; held: {held}.",
             "", "Checked means the current rule generator reproduced the exported properties. It is not deployment approval.",
             "No target overrides were applied. Review effective target overrides before adoption.",
             "Original exports are retained. Candidate rules keep existing GUIDs and enabled states.", ""]
    for error in input_errors:
        lines.append("- INPUT: " + error)
    unmanaged_items = [r for r in report if r["result"] == "unmanaged"]
    if unmanaged_items:
        lines.extend(["", "## Unmanaged by design (not converted, not deployed)", "",
                      "These are platform rule kinds without authored KQL. They stay in Sentinel",
                      "unchanged and are not part of any target selection.", ""])
        lines.extend(f"- {r['kind']}: {r['name']} ({r['id']})" for r in unmanaged_items)
    for item in report:
        if item["issues"] or item["warnings"]:
            lines.extend(["", "## " + (item["id"] or "Unresolved rule")])
            lines.extend("- " + str(issue) for issue in item["issues"])
            lines.extend("- Warning: " + str(w) for w in item["warnings"])
    (out / "conversion-report.md").write_text("\n".join(lines) + "\n", encoding="utf-8")
    print(f"Resolved {unique_count}/{expected_count} unique IDs; checked {checked}; "
          f"unmanaged {unmanaged}; needs review {held}.")
    return 2 if input_errors or any(r["issues"] for r in report) else 0


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--input", default="imports/sentinel-export")
    parser.add_argument("--out", default="conversion-output")
    parser.add_argument("--repo-root", default=".")
    parser.add_argument("--owner", default="security-engineering")
    parser.add_argument("--expected-count", type=int, default=68)
    args = parser.parse_args()
    if args.expected_count < 1:
        parser.error("--expected-count must be positive")
    try:
        return convert(Path(args.input), Path(args.out), Path(args.repo_root).resolve(),
                       args.owner, args.expected_count)
    except Exception as error:
        print("ERROR:", str(error), file=sys.stderr)
        return 1


if __name__ == "__main__":
    sys.exit(main())
