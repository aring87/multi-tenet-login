"""Regenerate GitHub's static dropdown choices from the validated client catalog."""
import argparse
import json
from pathlib import Path
from pipeline import ROOT, check_all
from target_matrix import ALL, PLACEHOLDER, SLOTS, target_ids

BEGIN="        # BEGIN GENERATED TARGET OPTIONS\n"
END="        # END GENERATED TARGET OPTIONS\n"
WORKFLOWS=("sentinel.yml","sentinel-multi-workspace.yml")


def update_text(text, names):
    count=text.count(BEGIN)
    if count not in (1,SLOTS) or text.count(END)!=count:
        raise ValueError("Expected 1 or "+str(SLOTS)+" generated target-options blocks, found "+str(count))
    remaining=text;parts=[]
    for index in range(count):
        start=remaining.index(BEGIN);finish=remaining.index(END,start)+len(END)
        parts.append(remaining[:start])
        options=[PLACEHOLDER,*([ALL] if index==0 else []),*names]
        block=BEGIN+"        options:\n"
        block+="".join("          - "+json.dumps(value)+"\n" for value in options)
        parts.append(block+END)
        remaining=remaining[finish:]
    return "".join(parts)+remaining


def read_workflow(path):
    """Return the file text and its newline, without translating line endings.

    read_text() strips carriage returns and write_text() re-adds os.linesep, so the
    same run rewrites every line ending to CRLF on Windows and to LF on a Linux
    runner. The workflow files here are CRLF and there is no .gitattributes, so
    without this the script produces a whole-file diff on every platform switch.
    """
    with path.open("r", encoding="utf-8", newline="") as stream:
        raw=stream.read()
    newline="\r\n" if "\r\n" in raw else "\n"
    return raw.replace("\r\n","\n"), newline


def write_workflow(path, text, newline):
    """Write text back using the newline the file already used."""
    with path.open("w", encoding="utf-8", newline="") as stream:
        stream.write(text.replace("\n", newline))


def main():
    parser=argparse.ArgumentParser();parser.add_argument("--check",action="store_true")
    args=parser.parse_args()
    names=target_ids(check_all(ROOT))
    changes=[]
    for name in WORKFLOWS:
        path=ROOT/".github"/"workflows"/name
        old,newline=read_workflow(path)
        new=update_text(old,names)
        if new!=old:changes.append((path,new,newline))
    if args.check and changes:
        raise SystemExit("Client dropdown is stale. Run python scripts/sync_target_choices.py and commit the workflow changes.")
    for path,text,newline in changes:write_workflow(path,text,newline)
    print("Dropdown catalog:",len(names),"enabled target(s).")


if __name__=="__main__":main()
