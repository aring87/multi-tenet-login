"""Validate one, several, or all enabled targets before starting any cloud jobs."""
import json
import os
import re
import sys
from pipeline import ROOT, check_all, selected_rules

ALL = "All enabled clients"
PLACEHOLDER = "Select a client"
MAX_TARGETS = 256
SLOTS = 8          # client dropdowns; 8 + rule_path + mode = the 10-input ceiling
TARGET_ID = re.compile(r"[a-z0-9]+(?:-[a-z0-9]+)*")


def target_ids(catalog):
    active=[]
    for name, target in catalog.items():
        if not isinstance(name,str) or not TARGET_ID.fullmatch(name) or len(name)>64:
            raise ValueError("Invalid target ID in catalog: " + repr(name))
        if type(target.get("enabled")) is not bool:
            raise ValueError("Target enabled must be a boolean: " + name)
        if target["enabled"]:active.append(name)
    return sorted(active,key=lambda value:(value.casefold(),value))


def resolve_targets(raw, rule_path="", selection="", single=False):
    raw, selection, rule_path=raw.strip(),selection.strip(),rule_path.strip()
    if selection and selection != PLACEHOLDER:
        if raw:raise ValueError("Choose the dropdown OR enter a subset, not both")
        raw=selection
    if not raw or raw == PLACEHOLDER:
        raise ValueError("Select a client, All enabled clients, or an explicit subset")
    if single and (raw == ALL or "," in raw):
        raise ValueError("Workspace worker requires exactly one target ID")
    requested=None if raw == ALL else [item.strip() for item in raw.split(",")]
    if requested is not None and (not all(requested) or len(set(requested))!=len(requested)):
        raise ValueError("Target list contains an empty or duplicate entry")
    catalog=check_all(ROOT)
    active=target_ids(catalog)
    targets=active if requested is None else sorted(requested)
    if not targets:raise ValueError("No enabled client targets found")
    if len(targets)>MAX_TARGETS:
        raise ValueError("GitHub supports at most 256 matrix targets; choose a smaller subset")
    for target_id in targets:
        if target_id not in active:raise ValueError("Unknown or disabled target: " + target_id)
        selected=selected_rules(ROOT,catalog[target_id])
        if not selected:raise ValueError("Target has no selected rules: " + target_id)
        if rule_path and not any(path == rule_path for path,_ in selected):
            raise ValueError("Rule is not selected for target " + target_id + ": " + rule_path)
    return targets


def resolve_choices(values, rule_path=""):
    if not isinstance(values,dict):raise ValueError("Client choices must be an object")
    choices=[]
    # GitHub rejects a workflow_dispatch with more than 10 inputs, and rule_path and
    # mode take two of them, so there are eight client slots.
    for key in ["target",*["target_"+str(i) for i in range(2,SLOTS+1)]]:
        value=values.get(key,PLACEHOLDER)
        if not isinstance(value,str):raise ValueError("Client choice must be a string")
        if value and value!=PLACEHOLDER:choices.append(value)
    if not choices:raise ValueError("Select at least one client")
    if ALL in choices:
        if len(choices)!=1:raise ValueError("Select All enabled clients alone; clear the other client dropdowns")
        return resolve_targets(ALL,rule_path)
    if len(set(choices))!=len(choices):raise ValueError("A client was selected more than once; clear the duplicate dropdown")
    if any(not TARGET_ID.fullmatch(value) for value in choices):raise ValueError("Invalid client dropdown selection")
    return resolve_targets(",".join(choices),rule_path)


def main():
    mode=os.environ.get("REQUESTED_MODE", "preview")
    if mode not in ("preview","deploy","query"):raise ValueError("Invalid mode")
    if "TARGET_CHOICES_JSON" in os.environ:
        targets=resolve_choices(json.loads(os.environ["TARGET_CHOICES_JSON"]),
                                os.environ.get("REQUESTED_RULE_PATH", ""))
    else:
        targets=resolve_targets(os.environ.get("REQUESTED_TARGETS", ""),
            os.environ.get("REQUESTED_RULE_PATH", ""),os.environ.get("TARGET_SELECTION", ""),
            os.environ.get("TARGET_SELECTION_SINGLE")=="true")
    result=json.dumps(targets,separators=(",", ":"))
    if "GITHUB_OUTPUT" in os.environ:
        with open(os.environ["GITHUB_OUTPUT"],"a",encoding="utf-8") as stream:
            stream.write("targets="+result+"\n")
    summary="Validated "+str(len(targets))+" target(s): "+", ".join(targets)
    print(summary)
    if "GITHUB_STEP_SUMMARY" in os.environ:
        with open(os.environ["GITHUB_STEP_SUMMARY"],"a",encoding="utf-8") as stream:
            stream.write("## Selected client workspaces\n\n"+summary+"\n\n")
            stream.write("Each target retains its own preview, bundle and production environment gate.\n")


if __name__ == "__main__":
    try:main()
    except (ValueError,KeyError,TypeError,OSError) as exc:
        print("ERROR:",exc,file=sys.stderr)
        sys.exit(1)
