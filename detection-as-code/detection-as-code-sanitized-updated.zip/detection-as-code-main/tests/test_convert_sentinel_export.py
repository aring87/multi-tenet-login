"""Offline tests use synthetic exports, never client data or Azure access."""
import copy
import importlib.util
import json
import tempfile
import unittest
from pathlib import Path
from types import SimpleNamespace
from unittest.mock import patch

import yaml

SCRIPT = Path(__file__).resolve().parents[1] / "scripts/convert_sentinel_export.py"
spec = importlib.util.spec_from_file_location("converter", SCRIPT)
c = importlib.util.module_from_spec(spec)
spec.loader.exec_module(c)
ID = "11111111-2222-4333-8444-555555555555"


def exported():
    return {
        "type": "Microsoft.OperationalInsights/workspaces/providers/alertRules",
        "name": "[concat(parameters('workspace'), '/Microsoft.SecurityInsights/" + ID + "')]",
        "kind": "Scheduled",
        "properties": {
            "displayName": "Existing enabled rule", "description": "First line\nSecond line",
            "enabled": True, "severity": "Medium", "query": "Table\n| where Value == 'yes'\n",
            "queryFrequency": "PT6H", "queryPeriod": "P7D", "triggerOperator": "GreaterThan",
            "triggerThreshold": 0, "tactics": [], "techniques": [],
            "suppressionEnabled": True, "suppressionDuration": "PT1H",
            "eventGroupingSettings": {"aggregationKind": "AlertPerResult"},
            "alertDetailsOverride": {"alertDisplayNameFormat": "Alert {{Name}}"},
            "customDetails": {"Device": "DeviceName"},
            "entityMappings": [{"entityType": "Host", "fieldMappings": [
                {"identifier": "FullName", "columnName": "DeviceName"}]}],
            "incidentConfiguration": {"createIncident": True, "groupingConfiguration": {
                "enabled": True, "lookbackDuration": "PT6H", "matchingMethod": "AllEntities",
                "reopenClosedIncident": False}},
            "alertRuleTemplateName": "aaaaaaaa-bbbb-4ccc-8ddd-eeeeeeeeeeee",
            "templateVersion": "1.2.0",
        },
    }


def fake_module(drop=None, extra=False, wrong_id=False):
    def template(rules):
        rule = rules[0]
        props = {k: copy.deepcopy(v) for k, v in rule.items() if k in c.DIRECT}
        props["displayName"] = rule["name"]
        props["incidentConfiguration"] = {
            k: copy.deepcopy(rule[k]) for k in ("createIncident", "groupingConfiguration") if k in rule}
        if drop:
            props.pop(drop, None)
        if extra:
            props["newSetting"] = False
        return {"resources": [{"type": "Microsoft.SecurityInsights/alertRules",
                                "name": "aaaaaaaa-bbbb-4ccc-8ddd-eeeeeeeeeeee" if wrong_id else rule["id"],
                                "kind": rule["kind"], "properties": props}]}
    return SimpleNamespace(validate=lambda rule, **kwargs: [], template=template)


class ConverterTests(unittest.TestCase):
    def test_literal_and_arm_ids(self):
        for name in [ID, "workspace/Microsoft.SecurityInsights/" + ID,
                     "[concat(parameters('workspace'), '/Microsoft.SecurityInsights/" + ID + "')]",
                     "[concat(parameters('workspace'), '/Microsoft.SecurityInsights/', '" + ID + "')]"]:
            self.assertEqual(c.resource_id({"name": name}), ID)

    def test_never_use_template_id_or_dynamic_expression(self):
        with self.assertRaises(ValueError):
            c.resource_id({"name": "[guid('seed')]", "properties": {"alertRuleTemplateName": ID}})

    def test_parameter_default_id(self):
        self.assertEqual(c.resource_id({"name": "[parameters('ruleId')]"},
                                       {"ruleId": {"defaultValue": ID}}), ID)

    def test_preserves_settings_and_yaml_query_exactly(self):
        source = exported()
        rule = c.candidate(source, ID, "security-engineering")
        self.assertIs(rule["enabled"], True)
        self.assertEqual(rule["id"], ID)
        self.assertEqual(rule["groupingConfiguration"], source["properties"]["incidentConfiguration"]["groupingConfiguration"])
        with tempfile.TemporaryDirectory() as folder:
            path = Path(folder) / "rule.yml"
            c.write_yaml(path, rule)
            self.assertEqual(yaml.safe_load(path.read_text(encoding="utf-8")), rule)
            self.assertIn("query: |", path.read_text(encoding="utf-8"))
        self.assertEqual(c.check_round_trip(rule, source, fake_module())[0], [])

    def test_dropped_setting_is_blocked(self):
        source = exported()
        rule = c.candidate(source, ID, "owner")
        self.assertTrue(c.check_round_trip(rule, source, fake_module(drop="suppressionEnabled"))[0])

    def test_added_setting_is_blocked(self):
        source = exported()
        self.assertTrue(c.check_round_trip(c.candidate(source, ID, "owner"), source, fake_module(extra=True))[0])

    def test_changed_id_is_blocked(self):
        source = exported()
        self.assertTrue(c.check_round_trip(c.candidate(source, ID, "owner"), source, fake_module(wrong_id=True))[0])

    def test_unknown_nested_setting_is_not_silently_dropped(self):
        source = exported()
        source["properties"]["incidentConfiguration"]["newSetting"] = True
        problems, _ = c.check_round_trip(c.candidate(source, ID, "owner"), source, fake_module())
        self.assertIn("properties.incidentConfiguration.newSetting: omitted by pipeline", problems)

    def test_unknown_kind_is_not_fabricated_as_scheduled(self):
        source = exported()
        source["kind"] = "NRT"
        with self.assertRaises(ValueError):
            c.candidate(source, ID, "owner")

    def test_no_pipeline_means_unverified(self):
        source = exported()
        self.assertTrue(c.check_round_trip(c.candidate(source, ID, "owner"), source, None)[0])

    def test_missing_state_is_not_defaulted(self):
        source = exported()
        del source["properties"]["enabled"]
        with self.assertRaises(ValueError):
            c.candidate(source, ID, "owner")

    def test_duplicate_json_key_rejected(self):
        with self.assertRaises(ValueError):
            json.loads('{"enabled":true,"enabled":false}', object_pairs_hook=c.unique_object)

    def test_batch_holds_duplicates_existing_ids_and_reports_count(self):
        with tempfile.TemporaryDirectory() as folder:
            root = Path(folder)
            inputs = root / "imports"
            inputs.mkdir()
            (inputs / "a.json").write_text(json.dumps({"resources": [exported(), exported()]}))
            library = root / "rules/sentinel"
            library.mkdir(parents=True)
            (library / "existing.yml").write_text("id: " + ID + "\n")
            code = c.convert(inputs, root / "out", root, expected_count=68)
            report = json.loads((root / "out/conversion-report.json").read_text())
            self.assertEqual(code, 2)
            self.assertEqual(report["checked"], 0)
            self.assertEqual(report["unique_rule_ids"], 1)
            self.assertEqual(len(report["rules"]), 2)
            self.assertTrue(any("already exists" in issue for issue in report["rules"][0]["issues"]))
            self.assertTrue(any("Duplicate GUID" in issue for issue in report["rules"][0]["issues"]))
            self.assertTrue(report["input_errors"])
            self.assertEqual(len(list((root / "out/needs-review").glob("*.yml"))), 2)
            self.assertEqual(yaml.safe_load((root / "out/target-selection-fragment.yml").read_text()), {"rules": []})
            with self.assertRaises(ValueError):
                c.convert(inputs, root / "out", root)

    def test_malformed_input_still_produces_report(self):
        with tempfile.TemporaryDirectory() as folder:
            root = Path(folder)
            inputs = root / "imports"
            inputs.mkdir()
            (inputs / "bad.json").write_text("{broken")
            self.assertEqual(c.convert(inputs, root / "out", root), 2)
            report = json.loads((root / "out/conversion-report.json").read_text())
            self.assertTrue(report["input_errors"])
            self.assertTrue((root / "out/original-exports/bad.json").exists())

    def test_read_only_timestamp_does_not_block(self):
        source = exported()
        source["properties"]["lastModifiedUtc"] = "2026-09-24T00:00:00Z"
        self.assertEqual(c.check_round_trip(c.candidate(source, ID, "owner"), source, fake_module())[0], [])

    def test_complete_68_rule_batch_preserves_ids_states_and_selection(self):
        with tempfile.TemporaryDirectory() as folder:
            root = Path(folder)
            inputs = root / "imports"
            inputs.mkdir()
            resources = []
            for number in range(68):
                resource = exported()
                resource["name"] = f"11111111-2222-4333-8444-{number:012d}"
                resource["properties"]["enabled"] = number != 0
                resources.append(resource)
            (inputs / "page1.json").write_text(json.dumps({"resources": resources[:50]}))
            (inputs / "page2.json").write_text(json.dumps({"resources": resources[50:]}))
            with patch.object(c, "load_pipeline", return_value=fake_module()):
                self.assertEqual(c.convert(inputs, root / "out", root), 0)
            report = json.loads((root / "out/conversion-report.json").read_text())
            self.assertEqual(report["checked"], 68)
            self.assertEqual(report["input_errors"], [])
            paths = yaml.safe_load((root / "out/target-selection-fragment.yml").read_text())["rules"]
            self.assertEqual(len(paths), 68)
            converted = [yaml.safe_load((root / "out/checked" / p["path"]).read_text()) for p in paths]
            self.assertEqual({rule["id"] for rule in converted}, {r["name"] for r in resources})
            self.assertEqual(sum(rule["enabled"] for rule in converted), 67)

    def test_workflow_has_no_azure_or_write_permissions(self):
        path = SCRIPT.parents[1] / ".github/workflows/convert-sentinel-export.yml"
        workflow = yaml.load(path.read_text(), Loader=yaml.BaseLoader)
        self.assertEqual(workflow["permissions"], {"contents": "read"})
        self.assertIn("workflow_dispatch", workflow["on"])
        steps = workflow["jobs"]["convert"]["steps"]
        self.assertFalse(any("azure" in s.get("uses", "").lower() for s in steps))
        self.assertEqual(steps[-1]["if"], "always()")


if __name__ == "__main__":
    unittest.main()