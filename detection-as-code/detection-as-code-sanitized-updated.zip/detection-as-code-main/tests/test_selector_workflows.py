"""Structural regression checks for the supplied workflow update."""
import unittest
from pathlib import Path
import sys
import yaml

sys.path.insert(0,str(Path(__file__).resolve().parents[1]/"scripts"))
from target_matrix import SLOTS

BASE=Path(__file__).resolve().parents[1]/".github"/"workflows"

class WorkflowTests(unittest.TestCase):
    def read(self,name):return yaml.load((BASE/name).read_text(encoding="utf-8"),Loader=yaml.BaseLoader)

    def test_dropdown_has_safe_default_and_all_option(self):
        for name in ("sentinel.yml","sentinel-multi-workspace.yml"):
            doc=self.read(name);field=doc["on"]["workflow_dispatch"]["inputs"]["target"]
            self.assertEqual(field["type"],"choice")
            self.assertEqual(field["default"],"Select a client")
            self.assertEqual(field["options"][:2],["Select a client","All enabled clients"])
            self.assertEqual(field["options"][2:],sorted(field["options"][2:]))
            jobs=doc["jobs"];self.assertEqual(jobs["run"]["needs"],"select")
            self.assertEqual(jobs["run"]["uses"],"./.github/workflows/sentinel-workspace.yml")
            self.assertEqual(jobs["run"]["strategy"]["max-parallel"],"3")
            self.assertEqual(jobs["run"]["strategy"]["fail-fast"],"false")

    def test_no_dispatch_workflow_exceeds_the_input_ceiling(self):
        for path in sorted(BASE.glob("*.yml")):
            doc=yaml.load(path.read_text(encoding="utf-8"),Loader=yaml.BaseLoader)
            inputs=(doc.get("on") or {}).get("workflow_dispatch") or {}
            inputs=inputs.get("inputs") or {} if isinstance(inputs,dict) else {}
            with self.subTest(workflow=path.name):
                self.assertLessEqual(len(inputs),10,
                                     path.name+" declares "+str(len(inputs))+
                                     " workflow_dispatch inputs; the limit is 10")

    def test_worker_retains_preview_approval_and_bundle_binding(self):
        doc=self.read("sentinel-workspace.yml")
        self.assertEqual(set(doc["on"]),{"workflow_call"})
        self.assertEqual(doc["concurrency"]["group"],"sentinel-target-${{ inputs.target }}")
        jobs=doc["jobs"]
        self.assertEqual(jobs["deploy"]["needs"],["prepare","preview"])
        self.assertEqual(jobs["deploy"]["environment"],"sentinel-production")
        self.assertEqual(jobs["preview"]["environment"],"sentinel-preview")
        self.assertIn("inputs.mode == 'deploy'",jobs["deploy"]["if"])
        for name in ("preview","deploy"):
            self.assertIn("EXPECTED_BUNDLE_DIGEST",jobs[name]["env"])
            self.assertIn("EXPECTED_TARGET",jobs[name]["env"])
        self.assertEqual(self.read("sentinel-full-check.yml")["jobs"]["check"]["uses"],"./.github/workflows/sentinel-workspace.yml")

    def test_multi_workflow_choices_fit_the_input_ceiling(self):
        doc=self.read("sentinel-multi-workspace.yml")
        inputs=doc["on"]["workflow_dispatch"]["inputs"]
        self.assertNotIn("targets",inputs)
        # GitHub rejects the whole workflow file above 10 inputs, so this is a hard
        # ceiling rather than a style preference.
        self.assertLessEqual(len(inputs),10,
                             "workflow_dispatch allows at most 10 inputs; GitHub will "
                             "reject this file as invalid")
        slots=[k for k in inputs if k=="target" or k.startswith("target_")]
        self.assertEqual(len(slots),SLOTS,"slot count must match target_matrix.SLOTS")
        for number in range(2,SLOTS+1):
            choice=inputs["target_"+str(number)]
            self.assertEqual(choice["type"],"choice")
            self.assertEqual(choice["default"],"Select a client")
            self.assertNotIn("All enabled clients",choice["options"])
            self.assertEqual(choice["options"][1:],inputs["target"]["options"][2:])
        env=doc["jobs"]["select"]["steps"][-1]["env"]
        self.assertEqual(env["TARGET_CHOICES_JSON"],"${{ toJSON(inputs) }}")
