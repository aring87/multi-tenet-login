"""Offline request-selection tests; cloud calls are never made."""
import importlib.util
import json
import os
import sys
import tempfile
import types
import unittest
from pathlib import Path
from unittest.mock import patch

BASE=Path(__file__).resolve().parents[1]


def load(name, filename, dependencies):
    spec=importlib.util.spec_from_file_location(name,BASE/"scripts"/filename)
    module=importlib.util.module_from_spec(spec)
    with patch.dict(sys.modules,dependencies):spec.loader.exec_module(module)
    return module


class SelectionTests(unittest.TestCase):
    def setUp(self):
        self.catalog={"z-client-primary":{"enabled":True,"rules":[("rules/sentinel/z.yml",{})]},
                      "a-client-primary":{"enabled":True,"rules":[("rules/sentinel/a.yml",{})]},
                      "disabled-primary":{"enabled":False,"rules":[]}}
        pipeline=types.ModuleType("pipeline");pipeline.ROOT=BASE
        pipeline.check_all=lambda root:self.catalog
        pipeline.selected_rules=lambda root,target:target["rules"]
        self.selector=load("selection_under_test","target_matrix.py",{"pipeline":pipeline})
        self.sync=load("sync_under_test","sync_target_choices.py",{"pipeline":pipeline,"target_matrix":self.selector})

    def test_all_enabled_is_sorted_and_excludes_disabled(self):
        self.assertEqual(self.selector.resolve_targets("All enabled clients"),["a-client-primary","z-client-primary"])

    def test_explicit_single_and_subset(self):
        self.assertEqual(self.selector.resolve_targets("z-client-primary"),["z-client-primary"])
        self.assertEqual(self.selector.resolve_targets("z-client-primary,a-client-primary"),["a-client-primary","z-client-primary"])

    def test_placeholder_empty_duplicate_unknown_and_disabled_fail(self):
        for value in ("", "Select a client","z-client-primary,", "z-client-primary,z-client-primary", "unknown", "disabled-primary"):
            with self.subTest(value=value),self.assertRaises(ValueError):self.selector.resolve_targets(value)

    def test_dropdown_and_subset_cannot_conflict(self):
        with self.assertRaises(ValueError):self.selector.resolve_targets("a-client-primary",selection="All enabled clients")
        self.assertEqual(self.selector.resolve_targets("a-client-primary",selection="Select a client"),["a-client-primary"])

    def test_rule_must_be_selected_for_every_target(self):
        with self.assertRaisesRegex(ValueError,"Rule is not selected"):
            self.selector.resolve_targets("All enabled clients","rules/sentinel/a.yml")
        self.assertEqual(self.selector.resolve_targets("a-client-primary","rules/sentinel/a.yml"),["a-client-primary"])

    def test_empty_rule_path_uses_each_targets_own_selection(self):
        self.assertEqual(len(self.selector.resolve_targets("All enabled clients","")),2)

    def test_empty_enabled_catalog_and_empty_rules_fail(self):
        self.catalog.clear()
        with self.assertRaisesRegex(ValueError,"No enabled"):self.selector.resolve_targets("All enabled clients")
        self.catalog["empty-primary"]={"enabled":True,"rules":[]}
        with self.assertRaisesRegex(ValueError,"no selected rules"):self.selector.resolve_targets("All enabled clients")

    def test_worker_cannot_expand_all_or_multiple(self):
        for value in ("All enabled clients","a-client-primary,z-client-primary"):
            with self.assertRaisesRegex(ValueError,"exactly one"):self.selector.resolve_targets(value,single=True)

    def test_matrix_limit_is_enforced(self):
        self.catalog.clear();self.catalog.update({f"client-{i}":{"enabled":True,"rules":[("rule",{})]} for i in range(257)})
        with self.assertRaisesRegex(ValueError,"256"):self.selector.resolve_targets("All enabled clients")

    def test_invalid_catalog_identifiers_and_flags_fail(self):
        for name,value in (("newline\nname",True),("a"*65,True),("valid", "true")):
            with self.subTest(name=name),self.assertRaises(ValueError):self.selector.target_ids({name:{"enabled":value}})

    def test_output_written_only_after_complete_validation(self):
        with tempfile.TemporaryDirectory() as folder:
            output=Path(folder)/"output"
            with patch.dict(os.environ,{"REQUESTED_TARGETS":"All enabled clients","REQUESTED_RULE_PATH":"rules/sentinel/a.yml","GITHUB_OUTPUT":str(output)},clear=True):
                with self.assertRaises(ValueError):self.selector.main()
                self.assertFalse(output.exists())
            with patch.dict(os.environ,{"REQUESTED_TARGETS":"All enabled clients","GITHUB_OUTPUT":str(output)},clear=True):self.selector.main()
            self.assertEqual(json.loads(output.read_text().split("=",1)[1]),["a-client-primary","z-client-primary"])

    def test_sync_is_idempotent_and_updates_both_dropdowns(self):
        names=self.selector.target_ids(self.catalog)
        for filename in self.sync.WORKFLOWS:
            original=(BASE/".github"/"workflows"/filename).read_text(encoding="utf-8")
            updated=self.sync.update_text(original,names)
            self.assertEqual(updated,self.sync.update_text(updated,names))
            self.assertIn('"a-client-primary"',updated)
            self.assertNotIn('"disabled-primary"',updated)
            self.assertIn("environment",(BASE/".github/workflows/sentinel-workspace.yml").read_text())
        with self.assertRaises(ValueError):self.sync.update_text("no markers",names)

    def test_multiple_dropdowns_skip_unused_slots(self):
        result=self.selector.resolve_choices({"target":"z-client-primary","target_2":"Select a client","target_5":"a-client-primary"})
        self.assertEqual(result,["a-client-primary","z-client-primary"])

    def test_dropdown_duplicates_and_mixed_all_are_rejected(self):
        for values in ({"target":"a-client-primary","target_2":"a-client-primary"},
                       {"target":"All enabled clients","target_2":"a-client-primary"},
                       {"target":"Select a client"},
                       {"target":"a-client-primary,z-client-primary"}):
            with self.subTest(values=values),self.assertRaises(ValueError):self.selector.resolve_choices(values)
        self.assertEqual(len(self.selector.resolve_choices({"target":"All enabled clients"})),2)

    def test_choices_json_uses_same_validated_matrix(self):
        with tempfile.TemporaryDirectory() as folder:
            output=Path(folder)/"output"
            values={"target":"a-client-primary","target_8":"z-client-primary","mode":"preview"}
            with patch.dict(os.environ,{"TARGET_CHOICES_JSON":json.dumps(values),"GITHUB_OUTPUT":str(output)},clear=True):
                self.selector.main()
            self.assertEqual(json.loads(output.read_text().split("=",1)[1]),["a-client-primary","z-client-primary"])
