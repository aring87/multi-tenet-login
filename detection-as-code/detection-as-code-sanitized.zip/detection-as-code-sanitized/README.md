# MSSP Sentinel Detection-as-Code

Manage Microsoft Sentinel analytics rules from one private GitHub repository, with a shared YAML rule library and a separate deployment target per client workspace.

**Status: four workspaces operational, across three tenants.** Validation, query checks, preview, production approval, and deployment have been exercised successfully for `hq-internal-primary`, `riverstone-integrations-workspace`, `ashgrove-federal-workspace` and `fernhill-consulting-workspace`, including a multi-workspace fan-out run. Access is now one identity pair for every client, via Azure Lighthouse delegation for client-owned tenants.

_Last updated: September 28, 2026. Status reflects work confirmed during implementation; it is not a live status feed._

## Deployment targets

| Client | Target | Tenant | Access model |
|---|---|---|---|
| `hq-internal` | `hq-internal-primary` | ExampleCo (`15a59fc2`) | In-tenant, group role assignments |
| `riverstone-integrations` | `riverstone-integrations-workspace` | ExampleCo (`15a59fc2`) | In-tenant, group role assignments |
| `ashgrove-federal` | `ashgrove-federal-workspace` | Bluestone | Lighthouse delegation |
| `fernhill-consulting` | `fernhill-consulting-workspace` | fernhill-consulting | Lighthouse delegation |

| Setting | Value |
|---|---|
| Repository | `example-org/detection-as-code` |
| Target configuration | `clients/<client>/workspace.yml` |
| Preview environment | `sentinel-preview` (shared by all targets) |
| Production environment | `sentinel-production` (shared by all targets) |
| Deployment branch | `main` |
| Deployment trigger | Manual selection of target and mode in GitHub Actions |

Tenant, subscription, resource group and workspace IDs are maintained in each target configuration. The target name selects a workspace; it is not the repository name.

**Naming inconsistency to resolve:** `hq-internal-primary` predates the `<client>-workspace` convention used by the other three. It works, but a future change should align it.

## Access model

One pair of Azure applications in the ExampleCo tenant serves every client. There are no per-client app registrations, federated credentials, GitHub environments or custom role definitions.

| Object | Purpose |
|---|---|
| `github-sentinel-lighthouse-preview` | Preview identity; one federated credential trusting `sentinel-preview` |
| `github-sentinel-lighthouse-deploy` | Deploy identity; one federated credential trusting `sentinel-production` |
| `sg-sentinel-pipeline-preview` | Holds the preview service principal |
| `sg-sentinel-pipeline-deploy` | Holds the deploy service principal |
| `sg-sentinel-detection-engineers` | Human read access for investigation |

Each group receives **built-in** roles at the client's Sentinel resource group:

| Group | Roles |
|---|---|
| `sg-sentinel-pipeline-deploy` | Microsoft Sentinel Contributor |
| `sg-sentinel-pipeline-preview` | Microsoft Sentinel Reader, Log Analytics Reader |
| `sg-sentinel-detection-engineers` | Microsoft Sentinel Reader, Reader |

**In-tenant clients** get those roles as direct assignments at resource-group scope. **Client-owned tenants** get them through an Azure Lighthouse delegation, deployed once per client subscription.

### Why built-in roles

Lighthouse authorizations accept built-in roles only; custom role definitions cannot be delegated. Rather than run two access models, the in-tenant clients were migrated to built-in roles as well and their per-client custom roles removed.

The accepted tradeoff: `Microsoft Sentinel Contributor` is broader than the retired writer role and includes delete on Sentinel content in that workspace. It does not grant RBAC write, Entra access, workspace deletion, table purge, or access to other resources in the subscription. The compensating controls are that nothing reaches a client except through a merged commit with a what-if artifact and an approval record, and that `sentinel-production` requires a reviewer.

### Credential scoping

Federated credentials are **environment-scoped** to the two shared environments. Entra caps federated credentials at 20 per app, so per-client environments could not scale; two fixed environments need two credentials in total, regardless of client count.

Consequence: preview/deploy separation comes from which client ID the workflow passes plus group membership, rather than Entra enforcing it per client. GitHub's approval gate on `sentinel-production` remains the control that matters.

**Known gap:** `sentinel-production` currently has a single reviewer who can approve their own deployments. Acceptable for a pilot; a second reviewer and prevent-self-review are needed before this is business as usual.

### Lighthouse delegation

One delegation per client subscription, deployed at subscription scope from within the client's tenant. Requires Owner or User Access Administrator there — a Sentinel role or Contributor alone is not sufficient, because creating a delegation is a role assignment in the client's directory.

Under this model a target file's `tenant_id` is the **managing** tenant (`15a59fc2`), not the client's. The workflow authenticates against ExampleCo's tenant and the delegated subscription is visible from there. Putting the client's tenant ID in that field makes login fail in a way that does not point at the cause.

Confirmed by deployment: `Microsoft Sentinel Contributor` does carry `Microsoft.Resources/deployments/*` against a Lighthouse-delegated subscription. No fallback to `Contributor` at resource-group scope was needed.

## How the pipeline works

1. **Author:** create or edit YAML rules in a working branch using GitHub's website.
2. **Select:** add the exact rule path to the intended workspace's target configuration.
3. **Review:** open a pull request and pass offline validation.
4. **Merge:** merge the approved change into main.
5. **Preview:** run the selected-workspace workflow in preview mode and inspect the proposed changes.
6. **Deploy:** start a deploy-mode run, review its fresh preview, and obtain production approval.
7. **Activate:** initially deploy new rules disabled; enable them through another reviewed deployment after functional testing.

**A merge does not automatically deploy to every client.** Each rollout explicitly selects one target, or an explicit list of targets.

Deploy mode previews and deploys the same generated bundle from the same commit. It applies all rules selected for that target, not just files changed in the latest pull request.

## Repository structure

```text
.github/
  workflows/
    ci.yml
    inspect-oidc.yml
    new-rule-id.yml
    sentinel.yml
    sentinel-multi-workspace.yml
    sentinel-full-check.yml
  dependabot.yml
  PULL_REQUEST_TEMPLATE.md

clients/
  riverstone-integrations/workspace.yml
  fernhill-consulting/workspace.yml
  ashgrove-federal/workspace.yml
  hq-internal/workspace.yml

rules/
  sentinel/
    aws/ endpoint/ health/ identity/ lastpass/
    testing/ threat-intelligence/

scripts/
  rules.py
  pipeline.py
  cloud.py
  target_matrix.py

templates/
  rule.yml.example
  CODEOWNERS.example

tests/
  test_pipeline.py

docs/
  rule-lifecycle-sop.md

requirements.txt
.gitignore
README.md
```

The `roles/` directory holding the four per-client custom role definitions is obsolete — those roles were deleted from both in-tenant subscriptions and cannot be delegated to client tenants. It should be removed.

YAML is the source of truth. GitHub Actions generates Azure deployment templates as run artifacts; authors do not manually build or commit generated ARM files.

## Workflow reference

| Workflow | Purpose | Writes Sentinel rules? |
|---|---|---|
| **Sentinel CI** | Validates rule metadata, YAML, target selection, and supported overrides | No |
| **Inspect Azure trust subject** | Displays the issuer, audience, and subject needed for federated trust | No |
| **Generate rule ID** | Generates a GUID for a new detection | No |
| **Sentinel - selected workspace** | Previews or deploys one explicitly selected workspace | Only in deploy mode, after configured approval |
| **Sentinel - multiple workspaces** | Fans one rule out across several selected targets | Only in deploy mode, after approval per target |
| **Sentinel - full client query check** | Checks selected rules for enabled targets weekly or manually | No |
| **Dependabot** | Proposes updates to GitHub Actions and Python dependencies through pull requests | No |

The full-check schedule is Monday at **06:00 UTC**. Its live scheduled execution still needs to be confirmed as an operational milestone.

`Sentinel - selected workspace` includes a **Resolve target** step that fails fast with the list of valid target names when the dispatch input is misspelled or the target is disabled. `Sentinel - multiple workspaces` calls it via `workflow_call` and inherits the shared environments; it requires every listed target to already select the requested rule, so a client cannot receive a rule they did not select.

Concurrency is keyed per target, so runs for different clients proceed in parallel while a rerun for the same client serializes.

## Quick start: add a rule

1. For a new detection, run **Actions → Generate rule ID** and copy its GUID. Preserve the GUID when updating an existing rule.
2. Create a YAML file under the appropriate data-source folder, such as `rules/sentinel/endpoint/`.
3. Keep the rule's top-level `enabled: false` for initial deployment.
4. Add its exact path to the target's existing `rules:` list.
5. Open a PR, pass CI, obtain review, and merge.
6. Run **Sentinel - selected workspace** with:

| Input | Preview run | Deployment run |
|---|---|---|
| Branch | `main` | `main` |
| Target | e.g. `fernhill-consulting-workspace` | e.g. `fernhill-consulting-workspace` |
| Mode | `preview` | `deploy` |

In preview mode, the production job should be **gray / Skipped**. In deploy mode, it should wait for the configured production reviewer before running.

Follow the [detailed rule lifecycle SOP](docs/rule-lifecycle-sop.md) for authoring, testing, approvals, activation, rollback, and troubleshooting.

### Example target selection

```yaml
rules:
  - path: rules/sentinel/testing/pipeline-connection-test.yml
  - path: rules/sentinel/endpoint/bitlocker-encryption-not-enabled.yml
```

There must be only one `rules:` entry. Replace `rules: []` when populating the list. A line beginning with `#` is a comment and does not select a rule.

### Reading a preview's what-if

The artifact lists every resource in the target resource group. Most entries have `changeType: Ignore` — unrelated resources the deployment does not touch. A new rule should produce exactly one non-`Ignore` entry, of type `Create`. A `Delete`, or an `Update` on a rule you did not intend to change, is a reason to stop.

## Understand the enabled settings

| Setting | Effect |
|---|---|
| Target's top-level `enabled: true` | Allows pipeline operations for that workspace |
| Rule's top-level `enabled: false` | Deploys the detection in a disabled state |
| Rule's top-level `enabled: true` | Activates the detection after successful deployment |
| `groupingConfiguration.enabled: true` | Enables incident grouping; does not activate the detection |

A target override takes precedence over the shared rule. For a rollout to one client, a target-specific `overrides.enabled` can control activation independently.

Setting the target to false does not disable a rule already running in Sentinel.

## Onboarding a new client

Per client, under the delegated model:

1. Obtain Owner or User Access Administrator on the client's subscription.
2. Register `Microsoft.ManagedServices` in that subscription if it is not already.
3. Deploy the Lighthouse delegation at subscription scope, granting the three ExampleCo groups their built-in roles.
4. Confirm a registration **assignment** exists, not only a definition — a deployment can report success with nothing actually delegated.
5. Commit a target file with `tenant_id` set to the managing tenant.
6. Run preview, then an approved deploy, with the connection-test rule.

No app registrations, credentials, environments or role definitions are created. Steps 1–5 are automated by the companion onboarding tool; step 1 is a human access-approval workflow and stays manual.

## Rule authoring conventions

- Use lowercase filenames with hyphens and exact matching paths.
- Keep existing rule IDs stable.
- Use ISO durations such as `PT6H` and `P7D`.
- Use `GreaterThan`, not `gt`.
- Indent multiline descriptions and KQL beneath `|`.
- Use ordinary KQL characters: `|` and `arg_max`, without Markdown escape backslashes.
- Keep custom-detail keys to **20 characters or fewer**. For example:
  `EncryptionStatus: EncryptionStatusString`.
- Use parent MITRE IDs in techniques; put sub-techniques in subTechniques with their parent also present.
- Missing MITRE metadata is currently permitted through `allow_missing_mitre: true`. Track this exception and remove it once the selected rules have appropriate metadata.
- An unencrypted-device result is not, by itself, proof of malicious activity. Detection descriptions and classifications should reflect that distinction.

Client folder name, the `client:` field and the target prefix must agree. CI rejects a mismatch, which is what prevents a target file in one client's folder from pointing at another client's workspace.

## What successful checks mean

A green CI run confirms the implemented offline checks passed.

A green preview confirms query acceptance and a successful what-if request. It does not guarantee that Azure will accept every property during deployment; the custom-detail key-length issue demonstrated that distinction.

The automated query check returning no matching rows is a check on the query, not on coverage. Functional result review and scheduled rule-run verification are separate from the pipeline checks.

A green deployment confirms Azure reported success applying the selected bundle. It does not, by itself, prove the rule has executed successfully on its schedule or generated the expected incident.

## Next milestones

### 1. Complete operational acceptance

- [ ] Activate the BitLocker rule through a reviewed change when the detection owner approves.
- [ ] Confirm a scheduled evaluation succeeds after activation.
- [ ] Confirm actual alert severity, entities, custom details, and incident behavior.
- [ ] Document or complete the MITRE metadata exception.
- [ ] Verify the weekly full-client query-check workflow executes successfully.
- [ ] Perform and record a controlled rollback or disablement test.
- [ ] Decide whether to retain the disabled connectivity-test rule per client.
- [ ] Confirm required PR checks, code reviewers, and deployment reviewers reflect team policy.

### 2. Close out the access-model migration

- [ ] Add a second production reviewer and enable prevent-self-review.
- [ ] Remove the obsolete `roles/` directory.
- [ ] Write the access-model decision record: built-in roles, what Sentinel Contributor grants, compensating controls, and the branch-to-environment credential change.
- [ ] Align `hq-internal-primary` with the `<client>-workspace` naming convention.
- [ ] Decide whether the two in-tenant workspaces migrate to delegation or stay as direct assignments.

### 3. Scale rule management

- [ ] Design a baseline rule set so a new shared rule does not require editing every client's target file.
- [ ] Decide how existing portal-managed rules in client workspaces are treated — imported, or left outside the repo.
- [ ] Raise `max-parallel` on the multi-workspace workflow, or batch rollouts, once throughput matters.
- [ ] Define a repeatable process for reviewing shared-rule changes across affected targets.

### 4. Improve long-term maintenance

- [ ] Add CI validation for custom-detail key lengths and other recurring deployment-time errors.
- [ ] Add a GitHub-visible post-deployment state check if the team needs automated enabled-state confirmation.
- [ ] Establish log/artifact retention and change-record requirements; current bundle retention is seven days.
- [ ] Review dependency-update PRs regularly.

## Operating boundaries

This repository provides separate deployment targets inside a shared MSSP-controlled repository. It does not provide separate code, log, or artifact visibility for each client. Keep access limited to authorized MSSP personnel.

The current implementation targets GitHub Enterprise Cloud and Azure public cloud. New client onboarding requires elevated access in the client's tenant; routine rule changes and deployment runs use GitHub's website.

Client workspaces typically contain many rules deployed outside this repository, from Content Hub or the portal. The pipeline manages only the rules a target explicitly selects; it is not a complete drift-auditing system, and full reapplication does not detect or remove unmanaged rules.

Deployments use Incremental mode. Removing a file or removing a target selection does **not** delete the live Sentinel rule. `Microsoft Sentinel Contributor` does permit rule deletion, so deletion is technically possible but is not performed by the pipeline.

When source files change, start a new workflow from the corrected main commit. Re-running failed jobs can reuse the earlier commit and bundle.

The pipeline uses custom GitHub Actions. Avoid configuring a competing content-deployment process to manage the same rules.

## Change records

For each rollout, retain the PR link, source commit, target, rule IDs, preview/deployment run links, approval, effective enabled state, and verification outcome.

For each client onboarding, retain the delegation deployment name, the registration assignment ID, and the target-file PR.

Update the target table and milestone sections as further clients and operational checks are confirmed.
