# SOP: Create and deploy a Sentinel detection rule

For analysts using only the GitHub website. No git commands, no software to
install, no Azure portal access needed. Everything happens in a browser.

You will need: a GitHub account with write access to the detection repository,
and the name of the client you are deploying to.

**Read this first.** Nothing you do in the website touches a client's Sentinel
workspace directly. A rule becomes live only after it is reviewed, merged, and
deployed through an approved pipeline run. You cannot accidentally break a
client by editing a file here. The only step that changes a client's workspace
is Step 9, and it stops for someone to approve it.

---

## Vocabulary

You do not need to understand git. You do need five words.

**Repository (repo)** — the folder of everything, living on GitHub. Ours is
`example-org/detection-as-code`.

**Branch** — a private copy of the repo where you can make changes without
affecting anyone. You make one, change things in it, and then ask for it to be
merged back. `main` is the real one that everything deploys from.

**Commit** — saving a change, with a note about what you did. Every commit is
kept forever, so mistakes are always recoverable.

**Pull request (PR)** — a request to merge your branch into `main`. This is
where automated checks run and where a colleague reviews your work.

**Merge** — accepting a PR, which puts your change into `main`.

**Workflow / Actions** — the automation that validates and deploys rules. You
trigger it with a button; it does the Azure work.

So the shape of the whole job is: make a branch, add a file, open a PR, get it
reviewed and merged, then press a button twice.

---

## Part 1 — Write the rule

### Step 1. Open the repository

Go to `github.com/example-org/detection-as-code` and sign in.

If you see a 404, your account does not have access yet. Ask for it rather
than creating your own copy of the repo.

### Step 2. Find a rule to copy from

Do not write a rule from a blank page. Start from a working one.

Click the **rules** folder, then **sentinel**, then a category folder —
`identity`, `endpoint`, `aws`, `threat-intelligence`, and so on. Open a rule
whose shape is close to what you want.

Click the **Copy raw file** button (the two-squares icon at the top right of
the file view) to put its full contents on your clipboard.

Read it before you reuse it. The fields you will be changing are the display
name, the description, the KQL query, the severity, and the MITRE tactics.

### Step 3. Get a new rule ID

Every rule needs its own unique ID. Reusing another rule's ID would make the
pipeline overwrite that rule instead of creating yours.

Go to the **Actions** tab, select **Generate rule ID** in the left sidebar,
click **Run workflow**, then **Run workflow** again in the green box.

Wait a few seconds, refresh, and click into the run that just appeared. The
generated ID is in the output. Copy it somewhere you can find it in a minute.

### Step 4. Create the rule file

Navigate to the category folder you want the rule to live in —
`rules/sentinel/identity`, say.

Click **Add file → Create new file**.

For the filename, use lowercase words separated by hyphens, ending in `.yml`:

```
suspicious-mailbox-forwarding-rule-created.yml
```

Check the breadcrumb above the filename box still shows the folder you meant.
It is easy to end up creating the file at the top level of the repo.

Paste the rule you copied in Step 2 into the big editing box, then change:

- the **id** — to the ID from Step 3
- the **display name** — what the analyst sees in Sentinel
- the **description** — what it detects and why it matters
- the **query** — your KQL
- the **severity** — Informational, Low, Medium or High
- the **tactics and techniques** — the MITRE mapping

Leave the structural fields alone. If you are not sure what a field does, leave
it exactly as the rule you copied had it.

### Step 5. Commit to a new branch

Scroll to the bottom of the page.

In the first box, write a short summary of what you did:

```
Add detection for suspicious mailbox forwarding rules
```

Select **Create a new branch for this commit and start a pull request**. GitHub
will suggest a branch name; the suggestion is fine, or name it something like
`add-mailbox-forwarding-rule`.

Click **Propose changes**.

**Do not** select "Commit directly to the main branch." Every change goes
through a pull request so that checks run and someone reviews it.

---

## Part 2 — Select the rule for a client

A rule existing in the repo does not send it anywhere. Each client has a file
listing the rules that client has selected. You have to add your rule to that
list, or nothing will deploy.

### Step 6. Add the rule to the client's target file

You should now be looking at the "Open a pull request" page. Before finishing
it, add the second change to the same branch.

Click the **Code** tab, and above the file list use the branch dropdown (it
says `main`) to select **your branch**. This matters — editing while `main` is
selected would start a second, separate change.

Navigate to **clients**, then the client's folder, then open **workspace.yml**.

Click the **pencil icon** to edit.

Find the `rules:` section near the bottom. It looks like this:

```yaml
rules:
  - path: rules/sentinel/identity/mfa-disabled-for-a-user.yml
  - path: rules/sentinel/endpoint/rdp-ingress.yml
```

Add a line for your rule, matching the indentation exactly — two spaces, a
hyphen, a space, then `path:`:

```yaml
rules:
  - path: rules/sentinel/identity/mfa-disabled-for-a-user.yml
  - path: rules/sentinel/endpoint/rdp-ingress.yml
  - path: rules/sentinel/identity/suspicious-mailbox-forwarding-rule-created.yml
```

Indentation is the single most common mistake here. The new line must line up
underneath the lines above it.

Do not change anything else in this file. The `tenant_id` value is correct as
it stands even though it may not look like the client's — leave it alone.

Scroll down, write a commit message like `Select mailbox forwarding rule for
<client>`, make sure **Commit directly to the <your-branch> branch** is
selected, and click **Commit changes**.

Repeat this step for each client that should get the rule.

### Step 7. Finish the pull request

Go to the **Pull requests** tab. Your PR should be listed; open it. If you did
not finish creating it earlier, GitHub will show a banner offering to open one
from your branch — use that.

In the description, say what the rule detects, which clients you selected it
for, and anything a reviewer should look at. Then click **Create pull request**.

---

## Part 3 — Get it checked and merged

### Step 8. Wait for checks, then get a review

At the bottom of the PR you will see checks running. Give it a minute.

**Green tick** — validation passed. Ask a colleague for a review.

**Red cross** — something needs fixing. Click **Details** next to the failed
check and read the last few lines of the log, which name the problem. The
common ones:

| Message | What to do |
|---|---|
| `Missing MITRE metadata` as a WARNING | Nothing. Warnings are expected and do not fail the run. |
| `Client folder, client field and target prefix must agree` | You edited the wrong client's file, or a name does not match. |
| `Rule does not exist` | The path you added in Step 6 has a typo. Compare it character by character against the actual file path. |
| A YAML or parsing error | Almost always indentation in Step 6. Check your new line lines up with the others. |
| `target ... is disabled in its target file` | That client's target has `enabled: false`. Ask before changing it — it may be deliberate. |

Fix by editing the file again on your branch; the checks re-run automatically.

When checks are green and a colleague has approved, click **Merge pull
request**, then **Confirm merge**. You can click **Delete branch** afterward;
it is tidy and loses nothing.

---

## Part 4 — Deploy

Merging puts the rule in the repo. It does **not** put it in a client's
workspace. That is this part, and it is two runs of the same workflow.

### Step 9. Preview first

Go to **Actions → Sentinel - selected workspace** → **Run workflow**.

Fill in:

- **target** — the client's target name, exactly. It is the `target:` value at
  the top of that client's `workspace.yml`, for example `ashgrove-federal-workspace`.
- **rule path** — the full path to your rule, for example
  `rules/sentinel/identity/suspicious-mailbox-forwarding-rule-created.yml`
- **mode** — `preview`

Click **Run workflow**, refresh, and open the run.

Preview changes nothing in Azure. It validates your KQL against the client's
actual workspace and produces a what-if showing what a deployment would do.

When it finishes, scroll to **Artifacts** at the bottom of the run summary and
download the `what-if-...` file. Open the JSON inside and look for the entries
where `changeType` is not `Ignore`. For a new rule you should see exactly one,
and it should be `Create`. Many `Ignore` entries are normal — they are other
resources in the same resource group that the deployment does not touch.

If you see `Delete`, or `Update` on a rule you did not intend to change, stop
and ask someone. Do not proceed.

If the target name is wrong, the run fails early and lists the valid target
names in the log. That is a safe failure; just rerun with the right one.

### Step 10. Deploy

Same workflow, **Run workflow** again, same target and rule path, but set
**mode** to `deploy`.

The run will pause and show **Review deployments**, waiting for an approval.
Someone with reviewer rights approves it — possibly you — and then the deploy
step runs.

### Step 11. Confirm it landed

Open the run and check the deploy job finished green.

If you have Azure access, the rule will be visible in the client's workspace
under **Microsoft Sentinel → Analytics**. New rules are normally deployed
disabled; enabling them is a separate, deliberate decision.

Tell whoever asked for the rule that it is deployed, and note whether it is
enabled or not.

---

## Deploying the same rule to several clients at once

Once the rule is merged and selected in more than one client's target file, use
**Actions → Sentinel - multiple workspaces**.

- **targets** — the target names separated by commas, for example
  `riverstone-integrations-workspace,ashgrove-federal-workspace`
- **rule path** — the same single rule path
- **mode** — `preview`, then `deploy`

Every client you list must already have that rule in its target file. If one
does not, the run fails before doing anything — which is the point, so a client
never receives a rule they did not select.

---

## If you get stuck

**You cannot find your change.** Check the branch dropdown on the Code tab. If
it says `main`, your work is on a different branch — switch to it.

**You edited the wrong branch.** Nothing is lost. Everything you commit is
saved somewhere. Ask for help rather than deleting anything.

**The checks stay red and the log makes no sense.** Paste the last twenty lines
of the failing step to whoever owns the pipeline. The error is usually a typo
in a path.

**You think you have broken something.** You almost certainly have not. Files
in the repo cannot affect a client until a deployment is approved and run. Ask.

## Things never to do

- Commit directly to `main`. Always use a branch and a pull request.
- Reuse another rule's ID.
- Change `tenant_id`, `subscription_id`, `workspace_id` or `resource_group` in
  a client's target file. Those come from onboarding and are correct as they
  are.
- Flip `enabled: false` to `true` in a target file without asking. It is often
  deliberate.
- Approve your own deployment when another reviewer is available.
- Run `deploy` without reading the preview's what-if first.
