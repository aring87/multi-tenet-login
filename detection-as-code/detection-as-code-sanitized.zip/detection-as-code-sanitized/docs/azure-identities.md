# Azure identity and access setup

One pair of app registrations serves every client. They already exist. This document
describes what they are, what access each client grants them, and what you do per
client — which is one delegation, or one set of role assignments.

**Nothing here is created per client except access to that client's resource group.**
No app registrations, no federated credentials, no custom role definitions.

## The identities (one time, already done)

All five objects live in the **ExampleCo tenant** (`15a59fc2-0b2e-44be-9445-8fabe80e3a7b`),
not in client tenants.

| Object | Purpose |
|---|---|
| `github-sentinel-lighthouse-preview` | Preview identity. One federated credential trusting the `sentinel-preview` environment. |
| `github-sentinel-lighthouse-deploy` | Deploy identity. One federated credential trusting the `sentinel-production` environment. |
| `sg-sentinel-pipeline-preview` | Security group holding the preview service principal. |
| `sg-sentinel-pipeline-deploy` | Security group holding the deploy service principal. |
| `sg-sentinel-detection-engineers` | Security group for human read access during investigation. |

Access is granted to the **groups**, never to the service principals directly. That
way a pipeline identity can be rotated, replaced or added without touching any
client's configuration.

Record the two Application (client) IDs; they are the `AZURE_CLIENT_ID` values in the
two shared GitHub environments and are the same for every client.

### Verifying group membership

`az ad group member list` does not reliably display service principal members in this
directory — it can return an empty list for a populated group. Check from the service
principal side instead:

```bash
az rest --method get \
  --url "https://graph.microsoft.com/v1.0/servicePrincipals/<SP_OBJECT_ID>/transitiveMemberOf?\$select=displayName,id"
```

An empty group is a silent failure: the delegation deploys, and the pipeline then
receives 403s that look identical to a missing permission.

## Federated credentials

Two credentials in total, both **environment-scoped**:

```
repo:example-org@308037977/detection-as-code@1309226902:environment:sentinel-preview
repo:example-org@308037977/detection-as-code@1309226902:environment:sentinel-production
```

Note the numeric organization and repository IDs. This organization issues
immutable-ID subject claims, not the documented name format. A credential using the
name format fails with `AADSTS700213` and the error does not explain why.

Use **Actions → Inspect Azure trust subject** to print the exact subject GitHub will
present, and match it character for character. The helper shows only public trust
claims, never a bearer token.

Environment scoping rather than branch scoping is deliberate. GitHub always mints an
environment-scoped subject for a job that declares an `environment:`, so a
branch-scoped credential cannot authenticate an environment-gated job at all.

Entra caps federated credentials at 20 per app. Two fixed environments need two
credentials regardless of client count; per-client environments would have needed two
per client and could not have scaled past ten.

**Consequence to understand:** preview/deploy separation now comes from which client
ID the workflow passes plus group membership, not from Entra enforcing it per client.
The approval gate on `sentinel-production` is the control that matters.

Do not add pull-request or general branch trust to these identities.

## Roles

Built-in roles only. Azure Lighthouse cannot delegate custom role definitions, so the
per-client custom roles that this document previously described were retired and
deleted from both in-tenant subscriptions.

| Group | Roles | Scope |
|---|---|---|
| `sg-sentinel-pipeline-deploy` | Microsoft Sentinel Contributor | Sentinel resource group |
| `sg-sentinel-pipeline-preview` | Microsoft Sentinel Reader, Log Analytics Reader | Sentinel resource group |
| `sg-sentinel-detection-engineers` | Microsoft Sentinel Reader, Reader | Sentinel resource group |

Verified role definition IDs:

| Role | ID |
|---|---|
| Microsoft Sentinel Contributor | `ab8e14d6-4a74-4a29-9ba8-549422addade` |
| Microsoft Sentinel Reader | `8d289c81-5878-46d4-8554-54e1e3d8b5cb` |
| Log Analytics Reader | `73c42c96-874c-492b-b04d-ab87d138a893` |
| Reader | `acdd72a7-3385-48ef-bd42-f606fba81ae7` |

### The tradeoff, stated plainly

`Microsoft Sentinel Contributor` is broader than the retired custom writer role. It
grants all of `Microsoft.SecurityInsights/*` — create, update **and delete** on
analytics rules, plus incident management and saved searches — along with
`Microsoft.Resources/deployments/*`, which is the part the pipeline needs.

It does **not** grant RBAC write, any Entra access, workspace deletion, table purge,
or access to other resources in the subscription. The realistic worst case is
destructive edits to Sentinel content in one workspace, not lateral movement.

Confirmed by deployment: this role does carry `deployments/write` against a
Lighthouse-delegated subscription. No fallback to `Contributor` at resource-group
scope was required.

The compensating controls are the approval gate on `sentinel-production`, and that
nothing reaches a client except through a merged commit with a what-if artifact and
an approval record. Do not respond to a missing permission by granting Owner to the
pipeline.

**Known gap:** `sentinel-production` currently has a single reviewer who can approve
their own deployments. Acceptable during the pilot; a second reviewer and
prevent-self-review are needed before this is routine.

## Per client: client-owned tenant

A client whose Sentinel workspace is in their own tenant gets an **Azure Lighthouse
delegation**. One deployment, at subscription scope, from inside their tenant.

### Access you need there

**Owner** or **User Access Administrator** on the target subscription. Creating a
delegation is a role assignment in the client's directory, so a Sentinel role or
Contributor alone is not enough.

`Microsoft.ManagedServices` must also be registered in that subscription, and
registering a provider is a subscription write that User Access Administrator does
not grant. In practice you need **both** Contributor and User Access Administrator
active at the same time. If either is PIM-eligible, activate it and then sign out and
back in — a role assignment is baked into the access token, so a freshly activated
role is invisible to a token issued before it.

### Deploying the delegation

Portal: **Deploy a custom template → Build your own template in the editor → Load
file →** `lighthouse-onboard.json`. Subscription scope, so no resource group selector
should appear. Parameters are the three group Object IDs; leave the managing tenant
and the four role IDs at their defaults.

CLI equivalent:

```bash
az deployment sub create \
  --name lighthouse-onboard-<slug> \
  --location eastus \
  --subscription <CLIENT_SUB> \
  --template-file lighthouse-onboard.json \
  --parameters deployGroupObjectId=<...> readGroupObjectId=<...> engineerGroupObjectId=<...>
```

The onboarding tool does both, plus the provider registration and the target-file
pull request.

### Confirm the assignment, not just the deployment

The delegation is **two** resources: a `registrationDefinition` and a
`registrationAssignment`. A deployment can report `Succeeded` with the definition
created and nothing actually delegated. Check explicitly:

```bash
az managedservices assignment list --subscription <CLIENT_SUB> -o table
```

If it is empty, bind it in the client's portal under **Service providers → Service
provider offers → Delegate subscriptions**, or redeploy.

Then verify from ExampleCo's tenant: **Azure Lighthouse → My customers → Delegations**
should show the client with status Succeeded and the deploy group's role. Note that
"My role" on the subscription blade shows *your own* effective access via the
engineers group, not what the pipeline identities hold.

## Per client: workspace inside the ExampleCo tenant

No delegation is possible — a subscription cannot be delegated to the tenant it
already lives in. Assign the same built-in roles directly to the three groups at the
Sentinel resource group:

```bash
SCOPE="/subscriptions/<SUB>/resourceGroups/<RG>"

MSYS_NO_PATHCONV=1 az role assignment create --assignee-object-id <DEPLOY_GRP> \
  --assignee-principal-type Group --role "Microsoft Sentinel Contributor" --scope "$SCOPE"
MSYS_NO_PATHCONV=1 az role assignment create --assignee-object-id <PREVIEW_GRP> \
  --assignee-principal-type Group --role "Microsoft Sentinel Reader" --scope "$SCOPE"
MSYS_NO_PATHCONV=1 az role assignment create --assignee-object-id <PREVIEW_GRP> \
  --assignee-principal-type Group --role "Log Analytics Reader" --scope "$SCOPE"
MSYS_NO_PATHCONV=1 az role assignment create --assignee-object-id <ENGINEER_GRP> \
  --assignee-principal-type Group --role "Microsoft Sentinel Reader" --scope "$SCOPE"
MSYS_NO_PATHCONV=1 az role assignment create --assignee-object-id <ENGINEER_GRP> \
  --assignee-principal-type Group --role "Reader" --scope "$SCOPE"
```

`MSYS_NO_PATHCONV=1` matters in Git Bash, which otherwise mangles the leading slash
in the scope path.

## The target file's tenant_id

Under a delegation, `tenant_id` in a target file is the **managing** tenant
(`15a59fc2`), not the client's.

The workflow authenticates against ExampleCo's tenant; the delegated subscription is simply
visible from there. The client is identified by `subscription_id`. Putting the
client's tenant ID in that field makes `az login` fail in a way that does not point
at the cause, and it is the single most common mistake in onboarding.

For workspaces inside the ExampleCo tenant the value is the same, because ExampleCo *is* the
tenant. The two cases only look different.

## Connect configuration

The two Application (client) IDs go into `AZURE_CLIENT_ID` in the two shared GitHub
environments — preview app in `sentinel-preview`, deploy app in
`sentinel-production`. Set once, never per client.

Tenant, subscription, resource group, workspace name and workspace GUID are recorded
in the client's target YAML.

No client secrets and no JIT passwords belong in the repository. Do not create a
built-in Sentinel repository connection for this workflow.

Azure CLI 2.76 or newer is required; the preview identity's what-if requests depend
on it.

[OIDC guidance](https://docs.github.com/en/actions/how-tos/secure-your-work/security-harden-deployments/oidc-in-azure)
· [What-if permissions](https://learn.microsoft.com/en-us/azure/azure-resource-manager/templates/deploy-what-if)
· [Azure Lighthouse delegated resource management](https://learn.microsoft.com/en-us/azure/lighthouse/concepts/architecture)
