# MSSP Sentinel Detection-as-Code

Manage Microsoft Sentinel analytics rules from one private GitHub repository, with a shared YAML rule library and separate deployment targets, Azure identities, and approvals for each client workspace.

**Status: the first workspace is operational.** Validation, query checks, preview, production approval, and deployment have been exercised successfully for `client-a-primary`. Additional workspace and tenant onboarding remains the next expansion milestone.

_Last updated: September 23, 2026. Status below reflects the completed work reported during implementation; it is not a live status feed._

## Current deployment target

| Setting | Value |
|---|---|
| Repository | `your-org/detection-as-code` |
| Client | `client-a` |
| Target | `client-a-primary` |
| Target configuration | `clients/client-a/workspace.yml` |
| Sentinel workspace | `law-client-a` |
| Resource group | `rg-sentinel` |
| Preview environment | `client-a-primary-preview` |
| Production environment | `client-a-primary-production` |
| Deployment branch | `main` |
| Deployment trigger | Manual selection of target and mode in GitHub Actions |

Tenant, subscription, and workspace IDs are maintained in the target configuration. The target name selects a workspace; it is not the repository name.

## Completed so far

- [x] Established the shared-rule and client-target folder structure.
- [x] Configured the first client target with its Azure identifiers.
- [x] Passed **Sentinel CI → Offline lint and target validation**.
- [x] Created separate preview and production GitHub environments.
- [x] Configured main-branch environment restrictions and production review.
- [x] Created separate Azure applications for preview and deployment.
- [x] Configured federated identity trust and environment-specific `AZURE_CLIENT_ID` variables.
- [x] Created and assigned resource-group operation roles and workspace-scoped access roles.
- [x] Successfully ran query checks and Azure what-if for the first target.
- [x] Successfully deployed a disabled pipeline connectivity test rule.
- [x] Successfully deployed the disabled BitLocker detection.
- [x] Reviewed the BitLocker results simulation and matching records in Sentinel.
- [x] Prepared a detailed GitHub-only rule lifecycle SOP.

### Deployed rules

| Rule | Rule ID | Last confirmed state |
|---|---|---|
| TEST - Pipeline connection | `aaaaaaaa-aaaa-4aaa-8aaa-aaaaaaaaaaaa` | Deployed and disabled |
| BitLocker disabled on managed Windows device - Intune | `bbbbbbbb-bbbb-4bbb-8bbb-bbbbbbbbbbbb` | Deployed and disabled; query results reviewed |

The reviewed BitLocker evaluation returned **8 matching records**. This does not mean eight new cases occurred that day: the query selects each device's latest available record within a seven-day lookback.

The BitLocker schedule is every six hours with a seven-day lookback. Once activated, devices can appear repeatedly while their reported state remains unencrypted. Activation and subsequent scheduled execution have not yet been confirmed.

## How the pipeline works

1. **Author:** create or edit YAML rules in a working branch using GitHub's website.
2. **Select:** add the exact rule path to the intended workspace's target configuration.
3. **Review:** open a pull request and pass offline validation.
4. **Merge:** merge the approved change into main.
5. **Preview:** run the selected-workspace workflow in preview mode and inspect the proposed changes.
6. **Deploy:** start a deploy-mode run, review its fresh preview, and obtain production approval.
7. **Activate:** initially deploy new rules disabled; enable them through another reviewed deployment after functional testing.

**A merge does not automatically deploy to every client.** Each rollout explicitly selects one target.

Deploy mode previews and deploys the same generated bundle from the same commit. It applies all rules selected for that target, not just files changed in the latest pull request.

## Repository structure

```text
.github/
  workflows/
    ci.yml
    inspect-oidc.yml
    new-rule-id.yml
    sentinel.yml
    sentinel-full-check.yml
  dependabot.yml
  PULL_REQUEST_TEMPLATE.md

clients/
  client-a/
    workspace.yml

rules/
  sentinel/
    endpoint/
      bitlocker-encryption-not-enabled.yml
    testing/
      pipeline-connection-test.yml

scripts/
  rules.py
  pipeline.py
  cloud.py

roles/
  preview-operations.json
  workspace-preview.json
  deployment-operations.json
  workspace-writer.json

templates/
  rule.yml.example
  CODEOWNERS.example

tests/
  test_pipeline.py

docs/
  rule-lifecycle-sop.md

requirements.txt
.gitignore
README.md
```

This shows the operational files and expected rule paths. Additional current setup/runbook documents may also remain under docs.

YAML is the source of truth. GitHub Actions generates Azure deployment templates as run artifacts; authors do not manually build or commit generated ARM files.

## Workflow reference

| Workflow | Purpose | Writes Sentinel rules? |
|---|---|---|
| **Sentinel CI** | Validates rule metadata, YAML, target selection, and supported overrides | No |
| **Inspect Azure trust subject** | Displays the issuer, audience, and subject needed for federated trust | No |
| **Generate rule ID** | Generates a GUID for a new detection | No |
| **Sentinel - selected workspace** | Previews or deploys one explicitly selected workspace | Only in deploy mode, after configured approval |
| **Sentinel - full client query check** | Checks selected rules for enabled targets weekly or manually | No |
| **Dependabot** | Proposes updates to GitHub Actions and Python dependencies through pull requests | No |

The full-check schedule is Monday at **06:00 UTC**. Its live scheduled execution still needs to be confirmed as an operational milestone.

## Quick start: add a rule

1. For a new detection, run **Actions → Generate rule ID** and copy its GUID. Preserve the GUID when updating an existing rule.
2. Create a YAML file under the appropriate data-source folder, such as `rules/sentinel/endpoint/`.
3. Keep the rule's top-level `enabled: false` for initial deployment.
4. Add its exact path to the target's existing `rules:` list.
5. Open a PR, pass CI, obtain review, and merge.
6. Run **Sentinel - selected workspace** with:

| Input | Preview run | Deployment run |
|---|---|---|
| Branch | `main` | `main` |
| Target | `client-a-primary` | `client-a-primary` |
| Mode | `preview` | `deploy` |

In preview mode, the production job should be **gray / Skipped**. In deploy mode, it should wait for the configured production reviewer before running.

Follow the [detailed rule lifecycle SOP](docs/Sentinel-Rule-Lifecycle-GitHub-SOP.md) for authoring, testing, approvals, activation, rollback, and troubleshooting.

### Example target selection

```yaml
rules:
  - path: rules/sentinel/testing/pipeline-connection-test.yml
  - path: rules/sentinel/endpoint/bitlocker-encryption-not-enabled.yml
```

There must be only one `rules:` entry. Replace `rules: []` when populating the list. A line beginning with `#` is a comment and does not select a rule.

## Understand the enabled settings

| Setting | Effect |
|---|---|
| Target's top-level `enabled: true` | Allows pipeline operations for that workspace |
| Rule's top-level `enabled: false` | Deploys the detection in a disabled state |
| Rule's top-level `enabled: true` | Activates the detection after successful deployment |
| `groupingConfiguration.enabled: true` | Enables incident grouping; does not activate the detection |

A target override takes precedence over the shared rule. For a rollout to one client, a target-specific `overrides.enabled` can control activation independently.

Setting the target to false does not disable a rule already running in Sentinel.

## Azure access model

| Application | Role | Assignment scope |
|---|---|---|
| `github-sentinel-client-a-primary-preview` | Sentinel Preview Operations | Resource group |
| Same preview application | Sentinel Workspace Preview | Exact Log Analytics workspace |
| `github-sentinel-client-a-primary-deploy` | Sentinel Deployment Operations | Resource group |
| Same deploy application | Sentinel Analytics Rule Writer | Exact Log Analytics workspace |

Each GitHub environment uses its matching application's **Application (client) ID** in `AZURE_CLIENT_ID`. Production uses the deploy application's ID.

Federated trust must match the environment's exact OIDC subject. A credential's display name alone does not establish the correct environment trust. Use the Inspect Azure trust subject workflow when checking that configuration.

No client secrets or JIT passwords belong in the repository.

## Rule authoring conventions

- Use lowercase filenames with hyphens and exact matching paths.
- Keep existing rule IDs stable.
- Use ISO durations such as `PT6H` and `P7D`.
- Use `GreaterThan`, not `gt`.
- Indent multiline descriptions and KQL beneath `|`.
- Use ordinary KQL characters: `|` and `arg_max`, without Markdown escape backslashes.
- Keep custom-detail keys to **20 characters or fewer**. For example:
  `EncryptionStatus: EncryptionStatusString`.
- Use parent MITRE IDs in techniques; put sub-techniques in subTechniques with their parent also present.
- Missing MITRE metadata is currently permitted for the pilot through `allow_missing_mitre: true`. Track this exception and remove it once the selected rules have appropriate metadata.
- An unencrypted-device result is not, by itself, proof of malicious activity. Detection descriptions and classifications should reflect that distinction.

## What successful checks mean

A green CI run confirms the implemented offline checks passed.

A green preview confirms query acceptance and a successful what-if request. It does not guarantee that Azure will accept every property during deployment; the custom-detail key-length issue demonstrated that distinction.

The automated query check returns no matching rows. Functional result review and scheduled rule-run verification are separate from the pipeline checks.

A green deployment confirms Azure reported success applying the selected bundle. It does not, by itself, prove the rule has executed successfully on its schedule or generated the expected incident.

## Next milestones

### 1. Complete operational acceptance for Client A

- [ ] Activate the BitLocker rule through a reviewed change when the detection owner approves.
- [ ] Confirm a scheduled evaluation succeeds after activation.
- [ ] Confirm actual alert severity, entities, custom details, and incident behavior.
- [ ] Review repeat detections and tune schedule/grouping if needed.
- [ ] Document or complete the pilot's MITRE metadata exception.
- [ ] Verify the weekly full-client query-check workflow executes successfully.
- [ ] Perform and record a controlled rollback or disablement test.
- [ ] Decide whether to retain the disabled connectivity-test rule.
- [ ] Upload the SOP as `docs/rule-lifecycle-sop.md` and agree on its operational owner.
- [ ] Confirm required PR checks, code reviewers, and deployment reviewers reflect team policy.

### 2. Prove multiple-workspace operation

- [ ] Add a second workspace as a separate target.
- [ ] Configure its own preview/production environments and identities.
- [ ] Assign workspace permissions at the intended scope.
- [ ] Select its rule set explicitly.
- [ ] Test a disabled rule and verify the first workspace is unaffected.
- [ ] Confirm per-target ID, severity, and enabled overrides behave as intended.

### 3. Prove separate-client tenant isolation

- [ ] Onboard a second authorized client tenant with separate identities and trust.
- [ ] Verify both targets' Azure identifiers and access scopes independently.
- [ ] Confirm each target receives only its selected content.
- [ ] Review failures and approval routing independently per client.
- [ ] Record the multi-client acceptance results before broad rollout.

### 4. Improve long-term maintenance

- [ ] Add CI validation for custom-detail key lengths and other recurring deployment-time errors.
- [ ] Add a GitHub-visible post-deployment state check if the team needs automated enabled-state confirmation.
- [ ] Establish log/artifact retention and change-record requirements; current bundle retention is seven days.
- [ ] Review dependency-update PRs regularly.
- [ ] Define a repeatable process for reviewing shared-rule changes across affected targets.

## Operating boundaries

This repository provides separate deployment targets inside a shared MSSP-controlled repository. It does not provide separate code, log, or artifact visibility for each client. Keep access limited to authorized MSSP personnel.

The current implementation targets GitHub Enterprise Cloud and Azure public cloud. New client identity and permission setup requires Azure/Entra administration; routine rule changes and deployment runs use GitHub's website.

The pipeline uses custom GitHub Actions. Avoid configuring a competing content-deployment process to manage the same rules.

Deployments use Incremental mode. Removing a file or removing a target selection does **not** delete the live Sentinel rule. Rule deletion is outside the current deployment identity's permissions.

When source files change, start a new workflow from the corrected main commit. Re-running failed jobs can reuse the earlier commit and bundle.

Full reapplication of selected rules does not detect or remove every unmanaged rule in the workspace. It is not a complete drift-auditing system.

## Change records

For each rollout, retain the PR link, source commit, target, rule IDs, preview/deployment run links, approval, effective enabled state, and verification outcome.

Update the completed-work and milestone sections as further targets and operational checks are confirmed.
