import copy
import importlib.util
import json
import os
from pathlib import Path
import sys
import tempfile
import unittest
from unittest.mock import patch
import yaml

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "scripts"))
import rules
import pipeline
import cloud
import migrate_export

def rule(identity="11111111-1111-4111-8111-111111111111"):
    return {
        "id": identity, "name": "Fixture detection",
        "description": "A detection fixture used only in offline tests.",
        "owner": "security-engineering", "status": "baseline",
        "enabled": False, "kind": "Scheduled", "severity": "Low",
        "tactics": ["CredentialAccess"], "techniques": ["T1110"],
        "queryFrequency": "PT1H", "queryPeriod": "PT1H",
        "query": "SecurityEvent | take 0",
    }

def target(name="client-a-primary", path="rules/sentinel/test.yml"):
    return {
        "version": 1, "target": name, "client": "client-a", "enabled": True,
        "allow_missing_mitre": False,
        "azure": {
            "tenant_id": "22222222-2222-4222-8222-222222222222",
            "subscription_id": "33333333-3333-4333-8333-333333333333",
            "workspace_id": "44444444-4444-4444-8444-444444444444",
            "resource_group": "rg-test", "workspace_name": "law-test",
        },
        "rules": [{"path": path}],
    }

class PipelineTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.root = Path(self.temp.name)
        self.write("rules/sentinel/test.yml", rule())
        self.write("clients/client-a/workspace.yml", target())

    def tearDown(self):
        self.temp.cleanup()

    def write(self, path, doc):
        file = self.root / path
        file.parent.mkdir(parents=True, exist_ok=True)
        file.write_text(yaml.safe_dump(doc), encoding="utf-8")
        return file

    def test_valid_rule_and_nrt(self):
        self.assertEqual(rules.validate(rule()), [])
        nrt = rule()
        nrt["kind"] = "NRT"
        del nrt["queryFrequency"], nrt["queryPeriod"]
        self.assertEqual(rules.validate(nrt), [])

    def test_quoted_boolean_rejected(self):
        doc = rule()
        doc["enabled"] = "false"
        with self.assertRaises(ValueError):
            rules.validate(doc)

    def test_duplicate_yaml_keys_rejected(self):
        file = self.root / "duplicate.yml"
        file.write_text("enabled: true\nenabled: false\n")
        with self.assertRaises(ValueError):
            rules.load_yaml(file)

    def test_malformed_and_zero_duration_rejected(self):
        for value in ("P", "PT", "PT0S", "1 hour"):
            with self.subTest(value=value), self.assertRaises(ValueError):
                rules.seconds(value)

    def test_unknown_rule_kind_and_field_rejected(self):
        for field, value in (("kind", "Fusion"), ("typoField", 1)):
            doc = rule()
            doc[field] = value
            with self.assertRaises(ValueError):
                rules.validate(doc)

    def test_id_placeholder_rejected(self):
        doc = rule("00000000-0000-0000-0000-000000000000")
        with self.assertRaises(ValueError):
            rules.validate(doc)

    def test_per_target_id_override_and_enable_preserved(self):
        t = target()
        t["rules"][0]["overrides"] = {
            "id": "aaaaaaaa-aaaa-4aaa-8aaa-aaaaaaaaaaaa", "enabled": True
        }
        self.write("clients/client-a/workspace.yml", t)
        _, checksum = pipeline.build(self.root, t["target"], self.root / "build")
        manifest, arm = pipeline.verify_bundle(self.root / "build", checksum)
        self.assertTrue(arm["resources"][0]["properties"]["enabled"])
        self.assertIn("aaaaaaaa-aaaa-4aaa-8aaa-aaaaaaaaaaaa", arm["resources"][0]["name"])

    def test_target_selects_only_explicit_rule(self):
        self.write("rules/sentinel/unselected.yml", rule("aaaaaaaa-aaaa-4aaa-8aaa-aaaaaaaaaaaa"))
        _, checksum = pipeline.build(self.root, "client-a-primary", self.root / "build")
        manifest, arm = pipeline.verify_bundle(self.root / "build", checksum)
        self.assertEqual(len(arm["resources"]), 1)

    def test_disabled_and_unknown_targets_fail(self):
        t = target()
        t["enabled"] = False
        self.write("clients/client-a/workspace.yml", t)
        for name in ("client-a-primary", "../../wrong"):
            with self.assertRaises(ValueError):
                pipeline.choose(self.root, name)

    def test_enabled_target_empty_rules_fails(self):
        t = target()
        t["rules"] = []
        self.write("clients/client-a/workspace.yml", t)
        with self.assertRaises(ValueError):
            pipeline.check_all(self.root)

    def test_path_escape_fails(self):
        for path in ("../test.yml", "rules/sentinel/../../outside.yml", "C:/outside.yml"):
            with self.subTest(path=path), self.assertRaises(ValueError):
                pipeline.rule_path(self.root, path)

    def test_duplicate_effective_ids_fail(self):
        second = "aaaaaaaa-aaaa-4aaa-8aaa-aaaaaaaaaaaa"
        self.write("rules/sentinel/second.yml", rule(second))
        t = target()
        t["rules"].append({"path": "rules/sentinel/second.yml", "overrides": {"id": rule()["id"]}})
        with self.assertRaises(ValueError):
            pipeline.selected_rules(self.root, t)

    def test_duplicate_workspace_registration_fails(self):
        self.write("clients/client-a/second.yml", target("client-a-second"))
        with self.assertRaises(ValueError):
            pipeline.load_catalog(self.root)

    def test_query_override_is_not_allowed(self):
        with self.assertRaises(ValueError):
            rules.apply_overrides(rule(), {"query": "different"})

    def test_mitre_exception_per_target(self):
        doc = rule()
        doc["techniques"] = []
        self.write("rules/sentinel/test.yml", doc)
        with self.assertRaises(ValueError):
            pipeline.check_all(self.root)
        t = target()
        t["allow_missing_mitre"] = True
        self.write("clients/client-a/workspace.yml", t)
        pipeline.check_all(self.root)

    def test_bundle_template_tampering_detected(self):
        _, checksum = pipeline.build(self.root, "client-a-primary", self.root / "build")
        (self.root / "build/template.json").write_text("{}")
        with self.assertRaises(ValueError):
            pipeline.verify_bundle(self.root / "build", checksum)

    def test_bundle_manifest_tampering_detected(self):
        _, checksum = pipeline.build(self.root, "client-a-primary", self.root / "build")
        (self.root / "build/bundle.json").write_text("{}")
        with self.assertRaises(ValueError):
            pipeline.verify_bundle(self.root / "build", checksum)

    def test_build_refuses_stale_output(self):
        pipeline.build(self.root, "client-a-primary", self.root / "build")
        with self.assertRaises(ValueError):
            pipeline.build(self.root, "client-a-primary", self.root / "build")

    def test_cloud_checks_logged_in_tenant(self):
        with patch.object(cloud, "az", return_value=json.dumps({"id": "wrong", "tenantId": "wrong"})):
            with self.assertRaises(ValueError):
                cloud.verify_target(target())

    def test_cloud_checks_workspace_customer_id(self):
        config = target()["azure"]
        account = {"id": config["subscription_id"], "tenantId": config["tenant_id"]}
        ws = {"id": "/wrong/workspace", "customerId": config["workspace_id"]}
        with patch.object(cloud, "az", side_effect=[json.dumps(account), json.dumps(ws)]):
            with self.assertRaises(ValueError):
                cloud.verify_target(target())

    def test_preview_and_deploy_use_same_file_and_incremental(self):
        manifest = {"target": target()}
        preview = cloud.deployment_args(manifest, Path("build"), "what-if")
        deploy = cloud.deployment_args(manifest, Path("build"), "create")
        for args in (preview, deploy):
            self.assertEqual(args[args.index("--template-file") + 1], str(Path("build/template.json")))
            self.assertEqual(args[args.index("--mode") + 1], "Incremental")
        self.assertIn("ProviderNoRbac", preview)
        self.assertNotIn("ProviderNoRbac", deploy)

    def test_query_probe_retains_multistatement_query(self):
        q = "let x = 1;\nSecurityEvent | where EventID == x; // end"
        self.assertEqual(cloud.probe(q), "let x = 1;\nSecurityEvent | where EventID == x\n| take 0")

    def test_migration_preserves_booleans_and_existing_id(self):
        r = rule()
        arm = rules.to_arm(r)
        arm["name"] = r["id"]
        result = migrate_export.convert(arm)
        self.assertEqual(result["id"], r["id"])
        self.assertIs(result["enabled"], False)
        self.assertEqual(result["query"], r["query"])

    def test_migration_rejects_unknown_properties(self):
        arm = rules.to_arm(rule())
        arm["name"] = rule()["id"]
        arm["properties"]["unknownNewSetting"] = True
        with self.assertRaises(ValueError):
            migrate_export.convert(arm)

    def test_retired_enabled_rule_rejected(self):
        doc = rule()
        doc.update(status="retired", enabled=True)
        with self.assertRaises(ValueError):
            rules.validate(doc)

    def test_two_clients_receive_different_selected_content(self):
        self.write("rules/sentinel/second.yml", rule("aaaaaaaa-aaaa-4aaa-8aaa-aaaaaaaaaaaa"))
        other = target("client-b-primary", "rules/sentinel/second.yml")
        other["client"] = "client-b"
        other["azure"]["tenant_id"] = "bbbbbbbb-bbbb-4bbb-8bbb-bbbbbbbbbbbb"
        other["azure"]["subscription_id"] = "cccccccc-cccc-4ccc-8ccc-cccccccccccc"
        other["azure"]["workspace_id"] = "dddddddd-dddd-4ddd-8ddd-dddddddddddd"
        self.write("clients/client-b/workspace.yml", other)
        _, first_hash = pipeline.build(self.root, "client-a-primary", self.root / "first")
        _, second_hash = pipeline.build(self.root, "client-b-primary", self.root / "second")
        first, _ = pipeline.verify_bundle(self.root / "first", first_hash)
        second, _ = pipeline.verify_bundle(self.root / "second", second_hash)
        self.assertNotEqual(first["rules"][0]["id"], second["rules"][0]["id"])
        self.assertNotEqual(first["target"]["azure"]["tenant_id"], second["target"]["azure"]["tenant_id"])

    def test_wrong_branch_cannot_reach_azure(self):
        with patch.dict(os.environ, {"GITHUB_REF": "refs/heads/feature"}), patch.object(sys, "argv", ["cloud.py", "deploy"]), patch.object(cloud, "az") as azure:
            with self.assertRaises(ValueError):
                cloud.main()
            azure.assert_not_called()

    def test_client_folder_must_agree(self):
        t = target()
        t["client"] = "client-b"
        self.write("clients/client-a/workspace.yml", t)
        with self.assertRaises(ValueError):
            pipeline.load_catalog(self.root)

    def test_query_parentheses_inside_strings_are_not_false_positives(self):
        doc = rule()
        doc["query"] = 'SecurityEvent | where tostring(EventID) contains "("'
        self.assertEqual(rules.validate(doc), [])

    def test_no_rule_delete_or_watchlist_write_in_roles(self):
        base = Path(__file__).resolve().parents[1] / "roles"
        for file in base.glob("*.json"):
            doc = json.loads(file.read_text())
            permissions = doc["properties"]["permissions"][0]
            for action in permissions["actions"]:
                self.assertNotIn("alertRules/delete", action)
                self.assertNotIn("Watchlists/write", action)
                self.assertNotIn("roleAssignments", action)

    def test_subtechnique_in_parent_field_rejected_even_during_migration(self):
        doc = rule()
        doc["techniques"] = ["T1562.004"]
        with self.assertRaises(ValueError):
            rules.validate(doc, allow_missing_mitre=True)

    def test_separate_subtechnique_compiles(self):
        doc = rule()
        doc["techniques"] = ["T1562"]
        doc["subTechniques"] = ["T1562.004"]
        self.assertEqual(rules.validate(doc), [])
        props = rules.to_arm(doc)["properties"]
        self.assertEqual(props["techniques"], ["T1562"])
        self.assertEqual(props["subTechniques"], ["T1562.004"])

    def test_subtechnique_requires_parent(self):
        doc = rule()
        doc["subTechniques"] = ["T1562.004"]
        with self.assertRaises(ValueError):
            rules.validate(doc)

    def test_parent_id_in_subtechnique_field_rejected(self):
        doc = rule()
        doc["subTechniques"] = ["T1110"]
        with self.assertRaises(ValueError):
            rules.validate(doc)

if __name__ == "__main__":
    unittest.main()
