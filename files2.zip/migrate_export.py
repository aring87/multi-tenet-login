"""Convert a rich legacy ArmTemplate CSV to downloadable YAML, without deploying."""
import argparse
import csv
import json
import re
import sys
from pathlib import Path
import yaml
from rules import guid, validate

ROOT = Path(__file__).resolve().parents[1]
KNOWN = {
    "displayName", "description", "severity", "enabled", "query", "queryFrequency",
    "queryPeriod", "triggerOperator", "triggerThreshold", "tactics", "techniques",
    "subTechniques", "incidentConfiguration", "suppressionDuration",
    "suppressionEnabled", "eventGroupingSettings", "entityMappings",
    "customDetails", "alertDetailsOverride",
}
SYSTEM_FIELDS = {"lastModifiedUtc", "alertRuleTemplateName", "templateVersion"}
DIRECT = {
    "severity", "enabled", "query", "queryFrequency", "queryPeriod", "triggerOperator",
    "triggerThreshold", "tactics", "techniques", "subTechniques", "suppressionDuration",
    "suppressionEnabled", "eventGroupingSettings", "entityMappings", "customDetails",
    "alertDetailsOverride",
}

def duration(value):
    if value is None or isinstance(value, str) and value.startswith("P"):
        return value
    match = re.fullmatch(r"(?:(\d+)\.)?(\d{1,2}):(\d{2}):(\d{2})", str(value))
    if not match:
        raise ValueError("Unrecognized exported duration")
    days, hours, minutes, seconds = [int(x or 0) for x in match.groups()]
    return ("P" + (str(days) + "D" if days else "") + "T" +
            str(hours) + "H" + str(minutes) + "M" + str(seconds) + "S")

def convert(resource, owner="detection-team"):
    if resource.get("kind") not in ("Scheduled", "NRT"):
        return None
    props = resource.get("properties", {})
    extra = set(props) - KNOWN - SYSTEM_FIELDS
    if extra:
        raise ValueError("Unsupported properties require migration review: " + ", ".join(sorted(extra)))
    identity = resource.get("name", "")
    if not guid(identity):
        raise ValueError("Legacy CSV ArmTemplate must contain a resource with a literal rule GUID")
    rule = {k: props[k] for k in DIRECT if k in props and props[k] is not None}
    rule.update({
        "id": identity.lower(), "name": props.get("displayName"),
        "description": props.get("description"), "owner": owner,
        "kind": resource["kind"],
        "status": "production" if props.get("enabled") is True else "baseline",
    })
    incident = props.get("incidentConfiguration") or {}
    if set(incident) - {"createIncident", "groupingConfiguration"}:
        raise ValueError("Unknown incidentConfiguration fields")
    rule["createIncident"] = incident.get("createIncident", False)
    if incident.get("groupingConfiguration"):
        rule["groupingConfiguration"] = incident["groupingConfiguration"]
    for key in ("queryFrequency", "queryPeriod", "suppressionDuration"):
        if key in rule:
            rule[key] = duration(rule[key])
    if rule["kind"] == "NRT":
        for key in ("queryFrequency", "queryPeriod", "triggerOperator", "triggerThreshold"):
            rule.pop(key, None)
    validate(rule, allow_missing_mitre=True)
    return rule

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--file", required=True)
    args = ap.parse_args()
    source = (ROOT / args.file).resolve()
    if not source.is_relative_to((ROOT / "imports").resolve()) or source.suffix != ".csv":
        raise ValueError("Select a CSV file inside imports/")
    with source.open(encoding="utf-8-sig", newline="") as stream:
        reader = csv.DictReader(stream)
        if "ArmTemplate" not in (reader.fieldnames or []):
            raise ValueError("CSV needs an ArmTemplate column. rule-register.csv is inventory only.")
        rows = list(reader)
    results, skipped, ids = [], [], set()
    for index, row in enumerate(rows, 2):
        raw = (row.get("ArmTemplate") or "").strip()
        if not raw:
            skipped.append("CSV row " + str(index) + ": no ArmTemplate; keep portal-managed")
            continue
        rule = convert(json.loads(raw))
        if rule is None:
            skipped.append("CSV row " + str(index) + ": unsupported kind; keep portal-managed")
            continue
        if rule["id"] in ids:
            raise ValueError("Duplicate imported rule ID")
        ids.add(rule["id"])
        results.append(rule)
    if not results:
        raise ValueError("No complete Scheduled/NRT rule definitions found")
    out = ROOT / "build/migration"
    if out.exists():
        raise ValueError("Migration output already exists")
    out.mkdir(parents=True)
    for rule in results:
        # GUID filenames avoid collisions and preserve identity; rename after import if desired.
        dest = out / "rules/sentinel/imported" / (rule["id"] + ".yml")
        dest.parent.mkdir(parents=True, exist_ok=True)
        dest.write_text(yaml.safe_dump(rule, sort_keys=False, allow_unicode=True), encoding="utf-8")
    (out / "MIGRATION-REPORT.md").write_text(
        "# Migration report\n\nConverted " + str(len(results)) +
        " rules. Review query, ID, enabled state and MITRE before selecting a target.\n\n" +
        "\n".join("- " + item for item in skipped) +
        "\n\nSystem template lineage fields are not carried into YAML.\n",
        encoding="utf-8",
    )
    print("Converted", len(results), "rules; skipped", len(skipped), "rows. No Azure access.")

if __name__ == "__main__":
    main()
