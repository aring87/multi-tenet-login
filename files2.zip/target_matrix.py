"""Validate a multi-target, single-rule request for GitHub Actions."""
import json
import os
import sys
from pipeline import ROOT, check_all, selected_rules


def main():
    raw_targets = os.environ.get("REQUESTED_TARGETS", "")
    rule_path = os.environ.get("REQUESTED_RULE_PATH", "")
    targets = [item.strip() for item in raw_targets.split(",") if item.strip()]
    if not targets:
        raise ValueError("Enter at least one target ID, separated by commas")
    if len(targets) != len(set(targets)):
        raise ValueError("Target list contains a duplicate")
    if not rule_path:
        raise ValueError("Enter the exact selected rule path")
    catalog = check_all(ROOT)
    for target_id in targets:
        if target_id not in catalog or not catalog[target_id]["enabled"]:
            raise ValueError("Unknown or disabled target: " + target_id)
        selected = selected_rules(ROOT, catalog[target_id])
        if not any(path == rule_path for path, _ in selected):
            raise ValueError("Rule is not selected for target " + target_id + ": " + rule_path)
    result = json.dumps(targets, separators=(",", ":"))
    if "GITHUB_OUTPUT" in os.environ:
        with open(os.environ["GITHUB_OUTPUT"], "a", encoding="utf-8") as stream:
            stream.write("targets=" + result + "\n")
    print("Validated rule", rule_path, "for targets:", ", ".join(targets))


if __name__ == "__main__":
    try:
        main()
    except (ValueError, KeyError, TypeError, OSError) as exc:
        print("ERROR:", exc, file=sys.stderr)
        sys.exit(1)
